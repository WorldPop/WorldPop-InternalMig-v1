# clear the workspace
rm(list=ls())

# set the path of the directory holding contiguity.csv and distance.csv
pathToInputCSVFile<-"C:/local/Migration/Namibia/Gravity/"

# set the path of the directory to put output in
pathToOutputCSVFile<-"C:/local/Migration/Namibia/"

#before running the code set CSV output table below (line 32) 

# get contiguity and distance
# read data from distance.csv and create a dataframe with columns CONTINENT,ISO,NODEI,NODEJ,DISTIJ,POPI,POPJ,AREAI,AREAJ,URBANPROPI,URBANPROPJ,LONFR,LATFR,LONTO,LATTO ordered by NODEI and NODEJ
distance <- read.csv( paste(pathToInputCSVFiles,"distance.csv",sep = ""),header=TRUE)
distance <- with(distance, data.frame(CONTINENT=CONTINENT,ISO=ISO,NODEI=NODEI,NODEJ=NODEJ,DISTIJ=DISTIJ,POPI=POPI,URBANPROPI=URBANPROPI,AREAI=AREAI,POPJ=POPJ,URBANPROPJ=URBANPROPJ,AREAJ=AREAJ,LONFR=LONFR,LATFR=LATFR,LONTO=LONTO,LATTO=LATTO))
distance <- distance[with(distance,order(NODEI,NODEJ)),]
# read data from contiguity.csv and create a data frame with columns NODEI,NODEJ,WEIGHT ordered by NODEI and NODEJ 
contiguity <- read.csv( paste(pathToInputCSVFiles,"contiguity.csv",sep = ""),header=TRUE)
contiguity <- with(contiguity, data.frame(NODEI=IPUMSID, NODEJ=NID, CONTIJ=WEIGHT))
contiguity <- contiguity[with(contiguity,order(NODEI,NODEJ)),]

# join distance with contiguity 
# merge automatically tries to match on columns with common names; in this case NODEI and NODEJ
# all.x=TRUE keep rows for x where there is no match found - like a left join
df <- merge(distance,contiguity,by.x=c("NODEI", "NODEJ"), by.y=c("NODEI", "NODEJ"), all.x=TRUE)

# set NA values in CONTIJ col to 0
df$CONTIJ[is.na(df$CONTIJ)] <- 0
rownames(df) <- NULL

# save the output table as CSV 
write.csv(df, paste(pathToOutputCSVFile, "Namibia_distance_contiguity.csv",sep=""), row.names=FALSE)

