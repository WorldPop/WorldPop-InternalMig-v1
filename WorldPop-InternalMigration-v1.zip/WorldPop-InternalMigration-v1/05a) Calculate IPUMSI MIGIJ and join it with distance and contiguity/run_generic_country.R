# to run this code from an R terminal:
#source('C:/worldppop/MigrationCopy/SRC/run_generic_country.R',echo=T)

# TO SOURCE THIS FILE IT MUST BE ENCODED AS UTF8 WITHOUT BOM -  plain UTF8 will kill the R terminal

# set the global variables below

# set the location of the script called generic_country.R
locationOfGenericCountryScripts<-"C:/local/Migration/"

# IMPORTANT - go to line 80 of generic_country and select the right query to use according to whether 
# the IPUMSI internal migration variables for the countries set to be run below (from line 38 on)
# were recorded by asking either i) the administrative unit of residence 5 years ago  
# or ii) the previous residence and the number of years residing in the current locality


# if 1 uses sql server version - if 0 uses postgres version
useSQLServerVersion<-0

# if using sql server database then the driver connection details should be set here
# for SQLServer express 2008 on a local machine; set the database name by editing DATABASE_NAME in the line here below
#sqlServerODBCConnectionDetails<-'driver={SQL Server Native Client 10.0}; server=localhost;database=DATABASE_NAME;trusted_connection=yes'
# SQLserver express 2005 on a local machine; set the database and computer name by editing DATABASE_NAME and PC_NAME in the line here below
sqlServerODBCConnectionDetails<-'driver={SQL Server}; server=PC_NAME\\SQLEXPRESS;database=DATABASE_NAME;trusted_connection=yes'


# if using postgres database then the ODBC connection details should be set here
# for postgres on a local machine; require to  set up an ODBC data source on the local machine
#postgresDriverODBCConnectionDetails<-'DSN=PostgresLocalHost;UID=postgres;PWD=PASSWORD;'
# for postgres on a server; set the data source name (PostGresSQLMigration), database user name (DATABASE_USER_NAME), and database password (PASSWORD)in the line here below (read settingUpPostGresODBCConnection.txt accompanying script 01)
postgresDriverODBCConnectionDetails<-'DSN=PostGresSQLMigration;UID=DATABASE_USER_NAME;PWD=PASSWORD;'

#########################################################################################
# set up all variables for one country here - several countries can be set up in one file
# the script can be run for multiple countries by copying the country code and setting the variables for each country
#########################################################################################################################

###################################################################
### SENEGAL 2002 - Administrative unit of residence 5 years ago ###
###################################################################

## an example of disabling code for a given country - everything inside the brackets will be ignored
## either remove the if and the brackets or change if(0) to if(1) to run this country
if(0){
# set the path of the directory to put output files in
outputDir<-"C:/local/Migration/Senegal_2002"

# set path of the the directory holding contiguity.csv and distance.csv
pathToInputCSVFiles<-"C:/local/Migration/Senegal_2002/Gravity/"

# specify the column name for nodes (i.e., spatial units) 
destination <- "DEPTSN"
origin <- "MIGSN"

# specify the names of the house and person tables in the database
houseTable <- "senegal2002houses"
personTable <- "senegal2002persons"

# used to name r.data output file
countryName<-'Senegal'

## and run the script for these settings
source(paste(locationOfGenericCountryScripts,"generic_country.R",sep = ""),echo=T)

}

########################
### End SENEGAL 2002 ###
########################


#######################################################################################################
### SOUTH AFRICA 2007 - Previous residence and the number of years residing in the current locality ###
#######################################################################################################

## an example of non-disabling code - everything inside the brackets will run
## change if(1) to if(0) to not run this country
if(1){
# set the path of the directory to put output files in
outputDir<-"C:/local/Migration/SouthAfrica_2007"

# set path of the the directory holding contiguity.csv and distance.csv
pathToInputCSVFiles<-"C:/local/Migration/SouthAfrica_2007/Gravity/"

# specify the column name for nodes (i.e., spatial units) 
destination <- "PROVZA"
origin <- "MIGZA1"

# specify the names of the house and person tables in the database
houseTable <- "southafrica2007houses"
personTable <- "southafrica2007persons"

# used to name r.data output file
countryName<-'SouthAfrica'

## and run the script for these settings
source(paste(locationOfGenericCountryScripts,"generic_country.R",sep = ""),echo=T)

}

#############################
### End SOUTH AFRICA 2007 ###
#############################
