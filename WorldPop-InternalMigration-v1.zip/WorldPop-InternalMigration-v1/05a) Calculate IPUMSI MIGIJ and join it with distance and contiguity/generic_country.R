# TO SOURCE THIS FILE IT MUST BE ENCODED AS UTF8 WITHOUT BOM - UTF8 will kill the R terminal

# IMPORTANT - go to line 80 below and select the right query to use according to whether 
# the IPUMSI internal migration variables for the countries set to be run in run_generic_country
# were recorded by asking either i) the administrative unit of residence 5 years ago  
# or ii) the previous residence and the number of years residing in the current locality

#library(ggplot2)
library(reshape)
library(RODBC)
#library(Metrics)

if(useSQLServerVersion){
	# output files will be put here
	setwd(outputDir)
	
	db <- odbcDriverConnect(sqlServerODBCConnectionDetails)

} else 
{
	# output files will be put here
	setwd(outputDir)
	
 	## this requires an ODBC connection to be set up on the local machine to the postgres database
 	## need to download and install postgres odbc drivers
	db <- odbcDriverConnect(postgresDriverODBCConnectionDetails,case = "postgresql")
}


# this function when run on a query replaces the strings destination, origin, houseTable and personTable with those specified in generic_country_5yr.R 
parameterizeQuery <- function(query) {
  query <- gsub("destination", destination, query)  
  query <- gsub("origin", origin, query)
  query <- gsub("houseTable", houseTable, query)
  query <- gsub("personTable", personTable, query)
  parameterizeQuery <- query
}

# calculate the IPUMSI population in each node in the census year (i.e., the census sample population in each spatial unit)
# IMPORTANT - make sure that the fields names e.g as NODE are enclosed by \" otherwise postgres returns them as lower case which messes things up
query <-
"SELECT destination AS \"NODE\", COUNT(destination) AS \"IPUMSPOP\"
FROM houseTable AS t1 JOIN personTable t2
ON t1.SERIAL = t2.SERIAL
GROUP BY destination
ORDER BY destination"
query <- parameterizeQuery(query)
nodes <- sqlQuery(db, query)

df1 <- with(nodes, data.frame(NODEJ=NODE, IPUMSPOP=IPUMSPOP))

# save df1
write.csv(nodes, file=paste(countryName,"_IPUMSPOP.csv",sep = ""), row.names=FALSE)

# read data from distance.csv and create a dataframe with columns CONTINENT,ISO,NODEI,NODEJ,DISTIJ,POPI,POPJ,AREAI,AREAJ,URBANPROPI,URBANPROPJ,LONFR,LATFR,LONTO,LATTO ordered by NODEI and NODEJ
distance <- read.csv( paste(pathToInputCSVFiles,"distance.csv",sep = ""),header=TRUE)
distance <- with(distance, data.frame(CONTINENT=CONTINENT,ISO=ISO,NODEI=NODEI,NODEJ=NODEJ,DISTIJ=DISTIJ,POPI=POPI,URBANPROPI=URBANPROPI,AREAI=AREAI, POPJ=POPJ,URBANPROPJ=URBANPROPJ,AREAJ=AREAJ, LONFR=LONFR,LATFR=LATFR,LONTO=LONTO,LATTO=LATTO))
distance <- distance[with(distance,order(NODEI,NODEJ)),]

# read data from contiguity.csv and create a data frame with columns NODEI,NODEJ,WEIGHT ordered by NODEI and NODEJ 
contiguity <- read.csv( paste(pathToInputCSVFiles,"contiguity.csv",sep = ""),header=TRUE)
contiguity <- with(contiguity, data.frame(NODEI=IPUMSID, NODEJ=NID, CONTIJ=WEIGHT))
contiguity <- contiguity[with(contiguity,order(NODEI,NODEJ)),]

# merge distance with contiguity 
# merge automatically tries to match on columns with common names, in this case NODEI and NODEJ
# all.x= true means we keep rows for x where there is no match found - like a left join
df2 <- merge(distance,contiguity,by.x=c("NODEI", "NODEJ"), by.y=c("NODEI", "NODEJ"), all.x=TRUE)

# set NA values in CONTIJ col to 0
df2$CONTIJ[is.na(df2$CONTIJ)] <- 0
rownames(df) <- NULL

# save df2 as csv 
write.csv(df2, file=paste(countryName,"_distance_contiguity.csv",sep = ""), row.names=FALSE)

# merge df1 with df2
df3 <- merge(df2,df1,by.x="NODEJ", by.y="NODEJ", all.x=TRUE)
# save df3 as csv 
write.csv(df3, file=paste(countryName,"IPUMSPOP_distance_contiguity.csv",sep = ""), row.names=FALSE)

################################################
# CALCULATE 5-YR MIGRATION FLOWS BETWEEN UNITS #
################################################

# 5 YEARS MIGRATION - VERY IMPORTANT put column names in quotes \" else postgres converts them to lower case
# and this will mess up the later merge

# calculate the number of people in the census sample that migrated from NODEI to NODEJ

# when running countries where IPUMSI internal migration variables were recorded by asking
# the administrative unit of residence 5 years ago
# use the query here below
query <-
"SELECT origin AS \"NODEI\", destination AS \"NODEJ\", COUNT(origin) as \"MIGIJ\"
FROM houseTable AS t1 INNER JOIN personTable AS t2
ON t1.SERIAL = t2.SERIAL
WHERE (MIG='t')
GROUP BY origin, destination
ORDER BY origin, destination"

# when running countries where IPUMSI internal migration variables were recorded by asking
# i) the previous residence and ii) the number of years residing in the current locality
# uncomment the query here below and comment out the one above
#query <-
#"SELECT origin AS \"NODEI\", destination AS \"NODEJ\", COUNT(origin) as \"MIGIJ\"
#FROM houseTable AS t1 INNER JOIN personTable AS t2
#ON t1.SERIAL = t2.SERIAL
#WHERE (MIG='t')
#AND MGYRS1 <= 1
#GROUP BY origin, destination
#ORDER BY origin, destination"

query <- parameterizeQuery(query)
migration <- sqlQuery(db, query)
df4 <- merge(df3, migration, all.x=TRUE)
df4$MIGIJ[is.na(df4$MIGIJ)] <- 0

# calculate MIGIJ/IPUMSPOP 
# (i.e., the percentage of people in NODEJ in the census year that were in NODEI 5 years prior to the census)
df4$PrpObs <- df4$MIGIJ/df4$IPUMSPOP
df4$PrpObs[is.na(df4$PrpObs)] <- 0
head(df4)
hist(df4$PrpObs)

# save full metrics (i.e., df4) as csv
write.csv(df4, file=paste(countryName,"_full_metrics_5yr.csv",sep = ""), row.names=FALSE)
