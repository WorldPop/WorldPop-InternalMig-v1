This application will write to either a Microsoft SQL Server database or a PostGres database.
These can either be local or via an ODBC connection.

To connect to a remote PostGres database you need to have installed a local PostGres client and set up an ODBC connection to the database on your local machine. See additional document called settingUpPostGresODBCConnection.txt

The connection details will then need setting in the code.

For a SQL Server database, edit line 18 in Main.css
Set defaultConnectionString to appropriate values.

For a PostGres database, edit line 42 in IpumsDataset.cs
Set connectionStringODBC to appropriate values.

and also edit line 46
postgresExeLocation with the location of the local PostGres client executable.

Set the remote server ip address in IpumsDataset.cs in 2 places.
On lines 411 and 422 look for "setToRemoteServerIPAddress" and replace it with the appropriate ip address.