﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ConsoleRedirection
{
	public sealed class RichTextBoxWriter : StringWriter
	{
		delegate void WriteCallBack(string text);

		private RichTextBox ConsoleBox { get; set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="RichTextBoxWriter"/> class.
		/// </summary>
		/// <param name="textBox">The text box.</param>
		public RichTextBoxWriter(RichTextBox richTextBox)
			: base()
		{
			ConsoleBox = richTextBox;
		}

		/// <summary>
		/// Writes a string to the text stream. As other processes use Console.Write, we have to use
		/// Invoke to avoid cross thread exception
		/// </summary>
		/// <param name="value">The string to write.</param>
		public override void Write(string message)
		{
			if (ConsoleBox.InvokeRequired)
			{
				WriteCallBack w = new WriteCallBack(Write);
				ConsoleBox.Invoke(w, new object[] { message });
			}
			else
			{
				ConsoleBox.AppendText(message);
				this.ScrollTextBoxEnd();
			}
			Application.DoEvents();
		}

		/// <summary>
		/// Writes a string followed by a line terminator to the text stream.
		/// </summary>
		/// <param name="value">The string to write. If value is null, only the line termination characters are written.</param>
		public override void WriteLine(string message)
		{

			if (ConsoleBox.InvokeRequired)
			{
				WriteCallBack w = new WriteCallBack(WriteLine);
				ConsoleBox.Invoke(w, new object[] { message });
			}
			else
			{
				this.ConsoleBox.AppendText(message);
				this.ConsoleBox.AppendText(Environment.NewLine);
				this.ScrollTextBoxEnd();
			}
			Application.DoEvents();
		}

		/// <summary>
		/// Scrolls the textbox to the end
		/// </summary>
		/// <param name="tb"></param>
		private void ScrollTextBoxEnd()
		{
			int length = ConsoleBox.Text.Length;
			ConsoleBox.Select(length, 1);
		}
	}
}
