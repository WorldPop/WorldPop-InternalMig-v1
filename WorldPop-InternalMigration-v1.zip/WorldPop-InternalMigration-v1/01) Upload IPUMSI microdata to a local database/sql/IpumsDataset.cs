﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using Microsoft.VisualBasic.FileIO;

using System.Windows.Forms;

using System.Data.Odbc;

namespace Ipums
{
	/// <summary>
	/// Represents an IPUMS dataset based off an extract and able to be copied into a database.
	/// </summary>
	public class IpumsDataSet
	{
		private string ExtractFilename { get; set; }
		private Extract IpumsExtract { get; set; }

		private string ConnectionString { get; set; }
		private SqlConnection SqlConnection;

		private DataTable HouseDataTable;
		private DataTable PersonDataTable;
		private int[] HouseFormat;
		private int[] PersonFormat;

		public bool HouseTableExists { get; set; }
		public bool PersonTableExists { get; set; }
		public bool MetaTableExists { get; set; }

        // if true assumes an odbc connection to a postgres database
        // else uses SQLServer
        public bool useODBCConnection = false;

        // this works forpostgres db on local machine
        //public string connectionStringODBC = "DSN=PostgresLocalHost;UID=postgres;PWD=replaceWithDatabasePassword;";
     

        // testing conecting to remote postgres database
        public string connectionStringODBC = "DSN=replaceWithODBCconnectionName;UID=malaria;PWD=replaceWithDatabasePassword;";

        // this needs to be set to whatever location it is on your machine
        // it should be similar to this
        public string postgresExeLocation = "C:\\Program Files\\PostgreSQL\\9.3\\bin\\psql.exe";
        
        private OdbcConnection odbcConnection;
        
        public SqlDataAdapter daHouseSQL;
        public SqlDataAdapter daPersonSQL;
        public SqlTransaction trSQL;

        public OdbcDataAdapter daHouseODBC;
        public OdbcDataAdapter daPersonODBC;
        public OdbcTransaction trODBC;

		/// <summary>
		/// Create an IPUMS dataset to interact between extract and a database.
		/// </summary>
		/// <param name="extract">IPUMS extract for dataset.</param>
		/// <param name="connectionString">Connection string for database.</param>
        public IpumsDataSet(Extract extract, string connectionString, bool useODBCConnection=false)
		{
			IpumsExtract = extract;
			ExtractFilename = extract.ExtractFilename;

            this.useODBCConnection = useODBCConnection;

            // test that the postgresExeLocation is correct
             if (!File.Exists(postgresExeLocation))
            {
                MessageBox.Show("The variable postgresExeLocation is not set to the correct location. You need to edit it in the file IpumsDataset.cs");

                throw new FileNotFoundException("The variable postgresExeLocation is not set to the correct location. You need to edit it in the file IpumsDataset.cs");
      
             }

			if (!File.Exists(ExtractFilename))
			{
				throw new FileNotFoundException("Extract file not found.", ExtractFilename);
			}

			// create fixed width formats for house
			HouseFormat = new int[IpumsExtract.HouseVariables.Count];
			for (int i = 0; i < HouseFormat.Length; ++i)
			{
				HouseFormat[i] = IpumsExtract.HouseVariables[i].Width;
			}

			// create fixed width formats for person
			PersonFormat = new int[IpumsExtract.PersonVariables.Count];
			for (int i = 0; i < PersonFormat.Length; ++i)
			{
				PersonFormat[i] = IpumsExtract.PersonVariables[i].Width;
			}

            if (!useODBCConnection)
            {
			    // open sql connection
			    ConnectionString = connectionString;
			    SqlConnection = new SqlConnection(connectionString);
			    SqlConnection.Open();
             }
             else      
             {
			    // open sql connection		
			    odbcConnection = new OdbcConnection(connectionStringODBC);
			     odbcConnection.Open();
             }

			// check if tables already exist
			CheckTables();
		}


		/// <summary>
		/// Check if house and person tables exist for this dataset.
		/// </summary>
		//private void CheckTables()
        public void CheckTables()
		{
            if (!useODBCConnection)
            {
			    string tableQuery = "SELECT * FROM [sys].[tables] WHERE [name] = @TABLE";
			    SqlCommand cmd = new SqlCommand(tableQuery, SqlConnection);
			    cmd.Parameters.Add("@TABLE", SqlDbType.VarChar);

			    // check for house table
			    cmd.Parameters["@TABLE"].Value = IpumsExtract.HouseTableName;
			    using (SqlDataReader sdr = cmd.ExecuteReader())
			    {
				    if (sdr.HasRows)
				    {
					    HouseTableExists = true;
				    }
			    }

			    // check for person table
			    cmd.Parameters["@TABLE"].Value = IpumsExtract.PersonTableName;
			    using (SqlDataReader sdr = cmd.ExecuteReader())
			    {
				    if (sdr.HasRows)
				    {
					    PersonTableExists = true;
				    }
			    }

			    // meta table exists
			    cmd.Parameters["@TABLE"].Value = IpumsExtract.MetaTableName;
			    using (SqlDataReader sdr = cmd.ExecuteReader())
			    {
				    if (sdr.HasRows)
				    {
					    MetaTableExists = true;
				    }
			    }
            }
            else
            {
			    //string tableQuery = "SELECT * FROM [sys].[tables] WHERE [name] = ?";
                string tableQuery = " SELECT table_name FROM information_schema.tables where table_name=?";
                
                //tableQuery += "'" + IpumsExtract.HouseTableName + "'"; 

			    OdbcCommand cmd = new OdbcCommand(tableQuery, odbcConnection);
			    cmd.Parameters.Add("@TABLE", OdbcType.VarChar);

			    // check for house table
			    //cmd.Parameters["@TABLE"].Value = IpumsExtract.HouseTableName;/
                // ICW - postgres seems to convert to lower case
                cmd.Parameters["@TABLE"].Value = IpumsExtract.HouseTableName.ToLower();

			    using (OdbcDataReader sdr = cmd.ExecuteReader())
			    {
				    if (sdr.HasRows)
				    {
					    HouseTableExists = true;
				    }
			    }

			    // check for person table
			    //cmd.Parameters["@TABLE"].Value = IpumsExtract.PersonTableName;
                cmd.Parameters["@TABLE"].Value = IpumsExtract.PersonTableName.ToLower();
			    using (OdbcDataReader sdr = cmd.ExecuteReader())
			    {
				    if (sdr.HasRows)
				    {
					    PersonTableExists = true;
				    }
			    }

			    // meta table exists
			   // cmd.Parameters["@TABLE"].Value = IpumsExtract.MetaTableName;
                cmd.Parameters["@TABLE"].Value = IpumsExtract.MetaTableName.ToLower();
			    using (OdbcDataReader sdr = cmd.ExecuteReader())
			    {
				    if (sdr.HasRows)
				    {
					    MetaTableExists = true;
				    }
			    }
            }
		}

        public void DropTables()
        {
            if (!useODBCConnection)
            {
            
                // drop person table
                if (PersonTableExists)
                {
               
                    string tableQuery = " drop table " + IpumsExtract.PersonTableName;
                    SqlCommand cmd = new SqlCommand(tableQuery, SqlConnection);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        PersonTableExists = false;
                    }
                    catch (Exception ex)
                    {
                        // do nothing
                    }
                }

                // drop house table
                if (HouseTableExists)
                {
                    string tableQuery = " drop table " + IpumsExtract.HouseTableName;
                    SqlCommand cmd = new SqlCommand(tableQuery, SqlConnection);
      
                    try
                    {
                        cmd.ExecuteNonQuery();
                        HouseTableExists = false;
                    }
                    catch (Exception ex)
                    {
                        // do nothing
                        Console.WriteLine("drop table fail" + ex.Message);
                    }
                }


              
            }
            else
            {
  
                // drop person table
                if (PersonTableExists)
                {
      
                    // the hacky unsafe way without a parameter - this works - not too much of a worrry here as 
                    // table name comes form a file name and we only have a couple of known users
                    string tableQuery = " drop table " + IpumsExtract.PersonTableName.ToLower();
                    OdbcCommand cmd = new OdbcCommand(tableQuery, odbcConnection);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        PersonTableExists = false;
                    }
                    catch (Exception ex)
                    {
                        // do nothing
                    }
                }

                // drop house table
                if (HouseTableExists)
                {
 
                    // the hacky unsafe way without a parameter - this works - not too much of a worrry here as 
                    // table name comes form a file name and we only have a couple of known users
                    string tableQuery = " drop table " + IpumsExtract.HouseTableName.ToLower();
                    OdbcCommand cmd = new OdbcCommand(tableQuery, odbcConnection);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        HouseTableExists = false;
                    }
                    catch (Exception ex)
                    {
                        // do nothing
                        Console.WriteLine("drop table fail" + ex.Message);
                    }
                }

            }
        }

        /// <summary>
        /// Process extract data into database.
        /// </summary>
        /// <param name="batchSize">Number of rows to parse before doing a bulk copy to database.</param>
        public void ProcessData(int batchSize)
        {

            if (!useODBCConnection)
            {
                ProcessDataSQLServer(batchSize);
            }
            else
            {
                ProcessDataPostgres(batchSize);
            }
         
        }

		/// <summary>
		/// Process extract data into database.
		/// </summary>
		/// <param name="batchSize">Number of rows to parse before doing a bulk copy to database.</param>
		public void ProcessDataPostgres(int batchSize)
		{
			Console.WriteLine("Processing data.");
			// create tables in memory and in database
			CreateTables();
			
            // set up extract and parser
			StreamReader sr = new StreamReader(ExtractFilename);
			TextFieldParser tfp = new TextFieldParser(sr);
			tfp.TextFieldType = FieldType.FixedWidth;

            // we will write data to CSVin hte directory where the xml file is
            // then COPY to postgres database
            // then delete the CSV files   

           // String fileHouse = "C:\\worldppop\\testCSV\\testOutputHouse.CSV";
            //String filePerson = "C:\\worldppop\\testCSV\\testOutputPerson.CSV";

             String fileHouse = Path.GetDirectoryName(ExtractFilename) + "\\HouseData.CSV";
             String filePerson = Path.GetDirectoryName(ExtractFilename) + "\\PersonData.CSV";

            StreamWriter swHouse = new StreamWriter(fileHouse, false);
            StreamWriter swPerson = new StreamWriter(filePerson, false);

            Console.WriteLine("Starting to process data, this may take a little while ...");

			while (!tfp.EndOfData)
			{
				// peek at line to see if its house or person
				string recordType = tfp.PeekChars(1);

				// parse house record
				if (recordType == "H")
				{
                    string lineHouse = "";

					tfp.SetFieldWidths(HouseFormat);
					string[] row = tfp.ReadFields();
					for (int i = 0; i < row.Length; ++i)
					{
                        lineHouse += (row[i]);

                        if (i != row.Length - 1)
                        {
                            lineHouse += ",";
                        }
					
					}

                    swHouse.WriteLine(lineHouse);

				}
				
				// parse person record
				else if (recordType == "P")
				{
                    string linePerson = "";

                    tfp.SetFieldWidths(PersonFormat);
                    string[] row = tfp.ReadFields();
                    for (int i = 0; i < row.Length; ++i)
                    {
                        linePerson += (row[i]);

                        if (i != row.Length - 1)
                        {
                            linePerson += ",";
                        }

                    }

                    swPerson.WriteLine(linePerson);
    
				}

				// unrecognized record
				else
				{
					throw new MalformedLineException(String.Format("Unexpected record type at line number {0}", tfp.LineNumber));
				}

			
			}

            swHouse.Close();
            swPerson.Close();

            Console.WriteLine("House and Person CSV files written");
    
            try
			{
                // we must do house first because of foregin key constraints
    
                // use for remote database -set ip address of remote server
                 System.Diagnostics.Process p1 = System.Diagnostics.Process.Start(postgresExeLocation, "-h setToRemoteServerIPAddress -d malaria -U malaria  -c \"\\copy " + IpumsExtract.HouseTableName.ToString() + " from '" + fileHouse + "' with csv\"");           

                // use for local host - not working
               // System.Diagnostics.Process p1 = System.Diagnostics.Process.Start(postgresExeLocation, "-h localhost -d malaria -U postgres  -c \"\\copy " + IpumsExtract.HouseTableName.ToString() + " from '" + fileHouse + "' with csv\"");           
          

                p1.WaitForExit();

                // use for remote database - set ip address of remote server
                System.Diagnostics.Process p2 = System.Diagnostics.Process.Start(postgresExeLocation, "-h setToRemoteServerIPAddress -d malaria -U malaria  -c \"\\copy " + IpumsExtract.PersonTableName.ToString() + " from '" + filePerson + "' with csv\"");         

                // use for local host - not working
               // System.Diagnostics.Process p2 = System.Diagnostics.Process.Start(postgresExeLocation, "-h localhost -d malaria -U postgres  -c \"\\copy " + IpumsExtract.PersonTableName.ToString() + " from '" + filePerson + "' with csv\"");           
          
                
                p2.WaitForExit();
                
            }
            catch (Exception ex)
            {

               Console.WriteLine("ERROR:Problem copying data to Postgres database Exception: " + ex.Message);
            }

            if (File.Exists(fileHouse))
            {
               // File.Delete(fileHouse);
            }

             if (File.Exists(filePerson))
            {
              //  File.Delete(filePerson);
            }

            Console.WriteLine("House and Person data written to database");
		}

        public void ProcessDataSQLServer(int batchSize)
        {
            Console.WriteLine("Processing data.");
            // create tables in memory and in database
            CreateDataTables();
            CreateTables();

            // use bulk copying
            SqlBulkCopy sbc = new SqlBulkCopy(SqlConnection);
            sbc.BatchSize = batchSize;


            // set up extract and parser
            StreamReader sr = new StreamReader(ExtractFilename);
            TextFieldParser tfp = new TextFieldParser(sr);
            tfp.TextFieldType = FieldType.FixedWidth;

            // parse data
            long currentBatch = 0;
            long totalRows = 0;
            long houseRows = 0;
            long personRows = 0;


            while (!tfp.EndOfData)
            {
                // peek at line to see if its house or person
                string recordType = tfp.PeekChars(1);

                // parse house record
                if (recordType == "H")
                {
                    tfp.SetFieldWidths(HouseFormat);
                    string[] row = tfp.ReadFields();
                    for (int i = 0; i < row.Length; ++i)
                    {
                        if (String.IsNullOrEmpty(row[i]))
                        {
                            row[i] = null;
                        }
                    }
                    HouseDataTable.Rows.Add(row);
                    houseRows++;
                }

                // parse person record
                else if (recordType == "P")
                {
                    tfp.SetFieldWidths(PersonFormat);
                    string[] row = tfp.ReadFields();
                    for (int i = 0; i < row.Length; ++i)
                    {
                        if (String.IsNullOrEmpty(row[i]))
                        {
                            row[i] = null;
                        }
                    }
                    PersonDataTable.Rows.Add(row);
                    personRows++;
                }

                // unrecognized record
                else
                {
                    throw new MalformedLineException(String.Format("Unexpected record type at line number {0}", tfp.LineNumber));
                }

                // finished row
                currentBatch++;
                totalRows++;

                // bulk copy once batch is large enough
                if (currentBatch == batchSize)
                {
                    currentBatch = 0;

                    sbc.DestinationTableName = IpumsExtract.HouseTableName;
                    sbc.WriteToServer(HouseDataTable);
                    HouseDataTable.Clear();

                    sbc.DestinationTableName = IpumsExtract.PersonTableName;
                    sbc.WriteToServer(PersonDataTable);
                    PersonDataTable.Clear();


                    Console.WriteLine("Processed " + totalRows + " rows: " + houseRows + " houses and " + personRows + " persons.");
                }
            }


            sbc.DestinationTableName = IpumsExtract.HouseTableName;
            sbc.WriteToServer(HouseDataTable);
            HouseDataTable.Clear();

            sbc.DestinationTableName = IpumsExtract.PersonTableName;
            sbc.WriteToServer(PersonDataTable);
            PersonDataTable.Clear();

            Console.WriteLine("Processed " + totalRows + " rows: " + houseRows + " houses and " + personRows + " persons.");
            Console.WriteLine("Finished processing data.");

            SqlConnection.Close();
        }

        public void ProcessDataThisWorksButIsVerySlow(int batchSize)
        {
            Console.WriteLine("Processing data.");
            // create tables in memory and in database
            CreateDataTables();
            CreateTables();

            // use bulk copying
            //SqlBulkCopy sbc = new SqlBulkCopy(SqlConnection);
            //sbc.BatchSize = batchSize;


            // set up extract and parser
            StreamReader sr = new StreamReader(ExtractFilename);
            TextFieldParser tfp = new TextFieldParser(sr);
            tfp.TextFieldType = FieldType.FixedWidth;

            // trying to capture time spent writing to database via different methods
            long startTicks = 0;
            long endTicks = 0;
            long totalTimeInTicks = 0;

            // parse data
            long currentBatch = 0;
            long totalRows = 0;
            long houseRows = 0;
            long personRows = 0;

            // ICW - BEGIN
            // set up datadapaters etc for  the 2 tables
            DataSet myDS = new DataSet();

            if (!useODBCConnection)
            {

                SqlCommand cmdHouse = new SqlCommand();
                cmdHouse.Connection = SqlConnection;

                cmdHouse.CommandText = "select * from " + IpumsExtract.HouseTableName.ToString();

                // try a data adapter and a data set for both house and person
                daHouseSQL = new SqlDataAdapter();
                daHouseSQL.SelectCommand = cmdHouse;

                SqlCommandBuilder cbHouse = new SqlCommandBuilder(daHouseSQL);


                SqlCommand cmdPerson = new SqlCommand();
                cmdPerson.Connection = SqlConnection;

                cmdPerson.CommandText = "select * from " + IpumsExtract.PersonTableName.ToString();

                // try a data adapter and a data set
                daPersonSQL = new SqlDataAdapter();
                daPersonSQL.SelectCommand = cmdPerson;

                SqlCommandBuilder cbPerson = new SqlCommandBuilder(daPersonSQL);

                //DataSet myDS = new DataSet();

                // use data adapter to fill data set
                daHouseSQL.Fill(myDS, "House");
                daPersonSQL.Fill(myDS, "Person");

                trSQL = SqlConnection.BeginTransaction();


                // just set the transaction for select and command builder will use it for other queries
                daHouseSQL.SelectCommand.Transaction = trSQL;
                daPersonSQL.SelectCommand.Transaction = trSQL;
            }
            else
            {

                OdbcCommand cmdHouse = new OdbcCommand();
                cmdHouse.Connection = odbcConnection;

                cmdHouse.CommandText = "select * from " + IpumsExtract.HouseTableName.ToString();

                // try a data adapter and a data set for both house and person
                daHouseODBC = new OdbcDataAdapter();
                daHouseODBC.SelectCommand = cmdHouse;

                OdbcCommandBuilder cbHouse = new OdbcCommandBuilder(daHouseODBC);

                OdbcCommand cmdPerson = new OdbcCommand();
                cmdPerson.Connection = odbcConnection;

                cmdPerson.CommandText = "select * from " + IpumsExtract.PersonTableName.ToString();

                // try a data adapter and a data set
                daPersonODBC = new OdbcDataAdapter();
                daPersonODBC.SelectCommand = cmdPerson;

                OdbcCommandBuilder cbPerson = new OdbcCommandBuilder(daPersonODBC);

                //DataSet myDS = new DataSet();

                // use data adapter to fill data set
                daHouseODBC.Fill(myDS, "House");
                daPersonODBC.Fill(myDS, "Person");

                trODBC = odbcConnection.BeginTransaction();

                // just set the transaction for select and command builder will use it for other queries
                daHouseODBC.SelectCommand.Transaction = trODBC;
                daPersonODBC.SelectCommand.Transaction = trODBC;
            }

            // ICW - END

            while (!tfp.EndOfData)
            {
                // peek at line to see if its house or person
                string recordType = tfp.PeekChars(1);

                // parse house record
                if (recordType == "H")
                {
                    tfp.SetFieldWidths(HouseFormat);
                    string[] row = tfp.ReadFields();
                    for (int i = 0; i < row.Length; ++i)
                    {
                        if (String.IsNullOrEmpty(row[i]))
                        {
                            row[i] = null;
                        }
                    }
                    //ICW20140908 HouseDataTable.Rows.Add(row);

                    // ICW
                    myDS.Tables["House"].Rows.Add(row);


                    houseRows++;
                }

                // parse person record
                else if (recordType == "P")
                {
                    tfp.SetFieldWidths(PersonFormat);
                    string[] row = tfp.ReadFields();
                    for (int i = 0; i < row.Length; ++i)
                    {
                        if (String.IsNullOrEmpty(row[i]))
                        {
                            row[i] = null;
                        }
                    }
                    //ICW20140908 PersonDataTable.Rows.Add(row);

                    // ICW
                    myDS.Tables["Person"].Rows.Add(row);

                    personRows++;
                }

                // unrecognized record
                else
                {
                    throw new MalformedLineException(String.Format("Unexpected record type at line number {0}", tfp.LineNumber));
                }

                // finished row
                currentBatch++;
                totalRows++;

                // bulk copy once batch is large enough
                if (currentBatch == batchSize)
                {

                    currentBatch = 0;

                    startTicks = DateTime.Now.Ticks;

                    //sbc.DestinationTableName = IpumsExtract.HouseTableName;
                    //sbc.WriteToServer(HouseDataTable);
                    //ICW20140908 HouseDataTable.Clear();



                    // ICW
                    if (!useODBCConnection)
                    {
                        daHouseSQL.Update(myDS, "House");
                    }
                    else
                    {

                        daHouseODBC.Update(myDS, "House");

                    }
                    myDS.Tables["House"].Clear();

                    //sbc.DestinationTableName = IpumsExtract.PersonTableName;
                    //sbc.WriteToServer(PersonDataTable);
                    //ICW20140908 PersonDataTable.Clear();

                    //ICW
                    if (!useODBCConnection)
                    {
                        daPersonSQL.Update(myDS, "Person");
                    }
                    else
                    {

                        daPersonODBC.Update(myDS, "Person");

                    }


                    myDS.Tables["Person"].Clear();

                    endTicks = DateTime.Now.Ticks;
                    totalTimeInTicks = totalTimeInTicks + endTicks - startTicks;

                    Console.WriteLine("Data added to database: " + totalRows + " rows: " + houseRows + " houses and " + personRows + " persons.");
                }
            }

            startTicks = DateTime.Now.Ticks;

            //sbc.DestinationTableName = IpumsExtract.HouseTableName;
            //sbc.WriteToServer(HouseDataTable);
            //ICW20140908 HouseDataTable.Clear();

            // ICW
            if (!useODBCConnection)
            {
                daHouseSQL.Update(myDS, "House");
            }
            else
            {
                daHouseODBC.Update(myDS, "House");
            }
            myDS.Tables["House"].Clear();

            //sbc.DestinationTableName = IpumsExtract.PersonTableName;
            //sbc.WriteToServer(PersonDataTable);
            //ICW20140908 PersonDataTable.Clear();

            // ICW
            if (!useODBCConnection)
            {
                daPersonSQL.Update(myDS, "Person");
            }
            else
            {
                daPersonODBC.Update(myDS, "Person");
            }
            myDS.Tables["Person"].Clear();

            if (!useODBCConnection)
            {
                trSQL.Commit();
            }
            else
            {
                trODBC.Commit();
            }

            endTicks = DateTime.Now.Ticks;
            totalTimeInTicks = totalTimeInTicks + endTicks - startTicks;

            Console.WriteLine("Time spent writing to database (seconds):" + (totalTimeInTicks / TimeSpan.TicksPerSecond).ToString());

            Console.WriteLine("Processed " + totalRows + " rows: " + houseRows + " houses and " + personRows + " persons.");
            Console.WriteLine("Finished processing data.");

            if (!useODBCConnection)
            {
                SqlConnection.Close();
            }
            else
            {
                odbcConnection.Close();
            }

        }





		public void LoadMetaData()
		{

		}


		/// <summary>
		/// Create database tables for house, person, and meta data.
		/// </summary>
		private void CreateTables()
		{
            if (!useODBCConnection)
            {
                // use a connection to sql server
                SqlCommand create = new SqlCommand(IpumsExtract.GetHouseSql(), SqlConnection);
                create.ExecuteNonQuery();
                Console.WriteLine("Created house table.");

                create = new SqlCommand(IpumsExtract.GetPersonSql(), SqlConnection);
                create.ExecuteNonQuery();
                Console.WriteLine("Created person table.");

                if (!MetaTableExists)
                {
                    create = new SqlCommand(IpumsExtract.GetMetaSql(), SqlConnection);
                    create.ExecuteNonQuery();
                }
            }
            else
            {
                // use a connection to sql server
                OdbcCommand create = new OdbcCommand(IpumsExtract.GetHouseSql(useODBCConnection), odbcConnection);
                create.ExecuteNonQuery();
                Console.WriteLine("Created house table.");

                create = new OdbcCommand(IpumsExtract.GetPersonSql(useODBCConnection), odbcConnection);
                create.ExecuteNonQuery();
                Console.WriteLine("Created person table.");

                if (!MetaTableExists)
                {
                    create = new OdbcCommand(IpumsExtract.GetMetaSql(useODBCConnection), odbcConnection);
                    create.ExecuteNonQuery();
                }
            }

		}


		/// <summary>
		/// Create in memory data tables for extract data.
		/// </summary>
		private void CreateDataTables()
		{
			HouseDataTable = new DataTable("Houses");
			foreach (Variable v in IpumsExtract.HouseVariables)
			{
				HouseDataTable.Columns.Add(v.ToDataColumn());
			}

			PersonDataTable = new DataTable("Persons");
			foreach (Variable v in IpumsExtract.PersonVariables)
			{
				PersonDataTable.Columns.Add(v.ToDataColumn());
			}
		}
	}
}
