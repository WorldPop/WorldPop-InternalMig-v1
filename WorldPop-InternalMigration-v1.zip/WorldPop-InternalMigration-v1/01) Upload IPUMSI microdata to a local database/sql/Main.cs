﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Ipums
{
	public partial class Main : Form
	{
		/// <summary>
		/// Default connection to ipums database on local server using windows authentication.
		/// </summary>
        /// 

        // connect to  SQL server 2008 on local machine
		//private string defaultConnectionString = "Data Source=(local);Initial Catalog=ipums;Integrated Security=True;";

        // connect to ICW SQL Server 2005 Express on local machine 
       private string defaultConnectionString = "Data Source=replaceWithYourSQLServerDataSourceLocation;Initial Catalog=ipums;uid=setWithYourDatabaseUserID;Integrated Security=True";
        
        /// <summary>
        /// Default number of records to read before doing a SqlBulkCopy to database.
        /// </summary>
		private int defaultBatchSize = 10000;

		public Main()
		{
			InitializeComponent();
			
			// default values
			tboxConnection.Text = defaultConnectionString;
			numBatch.Minimum = 1;
			numBatch.Maximum = System.Int32.MaxValue;
			numBatch.Value = defaultBatchSize;

			// set up console redirection
			ConsoleRedirection.RichTextBoxWriter consoleRedirect = new ConsoleRedirection.RichTextBoxWriter(rtbConsole);
			Console.SetOut(consoleRedirect);
		}

		private void SelectExtract(object sender, EventArgs e)
		{
			/*OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "XML Files (.xml)|*.xml|All Files (*.*)|*.*";
        

			if (ofd.ShowDialog() != DialogResult.Cancel)
			{
				// use selected file
				String filename = ofd.FileName;
				tboxXml.Text = filename;
			}
*/
            

            FolderBrowserDialog fbd = new FolderBrowserDialog();

            if (fbd.ShowDialog() != DialogResult.Cancel)
            {
                // use selected file
                //String filename = fbd.SelectedPath
                tboxXml.Text = fbd.SelectedPath;
            }

            

		}

		private void OnRun(object sender, EventArgs e)
		{
			// check file exists
			String xmlFilename = tboxXml.Text;


			/*if (!File.Exists(xmlFilename))
			{
				Console.WriteLine("ERROR: DDI file does not exist.");
				return;
			} */

            // changing this so that user can choose a directory or file
            // if a file then the file is procesed
            // if a directory then if it contains an xml file then just that xml file is processed
            // otherwise any sub dirs are checked for an xml file (allowing a bulk run)
            if (File.Exists(tboxXml.Text))
            {
                Extract ie = new Extract(tboxXml.Text);
                ProcessFile(ie);
            }
            else if (Directory.Exists(tboxXml.Text))
            {

               
                // check for files in the dir and run the first  ipumsi .xml file
                // if none then check sub dirs for impumsi file - this allows a batch run
                string ipumsiXMLFile = searchForIpumsiXMLFileInDir(tboxXml.Text);

                if (ipumsiXMLFile != null)
                {
                    Extract ie = new Extract(ipumsiXMLFile);
                    ProcessFile(ie);
                }
                else
                {
                   var dirs = Directory.EnumerateDirectories(tboxXml.Text);

                    foreach (var dir in dirs)
                    {
                     
                        ipumsiXMLFile = searchForIpumsiXMLFileInDir(dir);

                        if (ipumsiXMLFile != null)
                        {
                            Extract ie = new Extract(ipumsiXMLFile);
                            ProcessFile(ie);
                        }
                    }
                  
                }

             
            }
            else
            {
                Console.WriteLine(tboxXml.Text + " is not an existing file or directory");
            }

			
		}

        private string searchForIpumsiXMLFileInDir(string dirName)
        {
            // this returns the first .xml file found with ipumsi in the name 
            string fileFound = null;

            var filesInDir = Directory.EnumerateFiles(dirName);

            foreach (string fl in filesInDir)
            {
            
                if (Path.GetFileName(fl).ToLower().Contains("ipumsi") && Path.GetExtension(fl) == ".xml")
                {
                    fileFound = fl;
                    break;
                }
            }

            return fileFound;
        }


        private bool ProcessFile(Extract ie)
        {
            bool success = true;

            //Extract ie = new Extract(xmlFilename);
            if (!File.Exists(ie.ExtractFilename))
            {
                Console.WriteLine("ERROR: Extract file does not exist. Make sure extract file(.dat.gz) has been downloaded into same directory AND unzipped (.dat).");
                return false;
            }


            string connectionString = tboxConnection.Text;

            IpumsDataSet id;

            try
            {
                id = new IpumsDataSet(ie, connectionString, usePostGres_checkBox.Checked);

                // ICW -20140908 added check box to choose between postGres and SQLServer
                // check its state here and set coonection accordingingly
                if (usePostGres_checkBox.Checked == true)
                {
                    // use ODBC connection to postgres database   
                    tboxConnection.Text = id.connectionStringODBC;
                }
                else
                {
                    // coonect to local SQL server database
                    tboxConnection.Text = defaultConnectionString;
                }

                // ICW
                // if tables already exist in database give user the option to delete them
                id.CheckTables();
                if (id.HouseTableExists || id.PersonTableExists)
                {
                    if (autoDeleteExistingTablesCheckBox.Checked == true)
                    {
                        id.DropTables();
                    }
                    else
                    {
                        DialogResult msgBoxResponse = MessageBox.Show(ie.ExtractFilename + " One or more of the tables exists already. Do you want to delete them?", "Table Exists Message", MessageBoxButtons.YesNo);

                        if (msgBoxResponse == DialogResult.Yes)
                        {
                            id.DropTables();

                        }
                    }
                }

                // do not overwrite existing tables/data
                if (id.HouseTableExists)
                {
                    Console.WriteLine("ERROR: House table for this extract already exists and will not be overwritten.");
                    return false;
                }
                if (id.PersonTableExists)
                {
                    Console.WriteLine("ERROR: Person table for this extract already exists and will not be overwritten.");
                    return false;
                }

                try
                {
                    // process data 10,000 rows at a time
                    id.ProcessData(Convert.ToInt32(numBatch.Value));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("ERROR: Unable to process data.");
                    Console.WriteLine("ERROR: Exception: " + ex.Message);

                    success = false;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: Unable to create IPUMS dataset.");
                Console.WriteLine("ERROR: Exception: " + ex.Message);

                success = false;
            }

            return success;
        }

   

        /*
            private void OnRun(object sender, EventArgs e)
        {
            // check that dat and codebook exist
            String xmlFilename = tboxXml.Text;
            if (!File.Exists(xmlFilename))
            {
                Console.WriteLine("ERROR: DDI file does not exist.");
                return;
            }

            Extract ie = new Extract(xmlFilename);
            if (!File.Exists(ie.ExtractFilename))
            {
                Console.WriteLine("ERROR: Extract file does not exist. Make sure extract file(.dat.gz) has been downloaded into same directory AND unzipped (.dat).");
                return;
            }


            string connectionString = tboxConnection.Text;

            IpumsDataSet id;

            try
            {
                id = new IpumsDataSet(ie, connectionString, usePostGres_checkBox.Checked);

                // ICW -20140908 added check box to choose between postGres and SQLServer
                // check its state here and set coonection accordingingly
                if (usePostGres_checkBox.Checked == true)
                {
                    // use ODBC connection to postgres database   
                    tboxConnection.Text = id.connectionStringODBC;
                }
                else
                {
                    // coonect to local SQL server database
                    tboxConnection.Text = defaultConnectionString;
                }

                // ICW
                // if tables already exist in database give user the option to delete them
                id.CheckTables();
                if (id.HouseTableExists || id.PersonTableExists)
                {
                    DialogResult msgBoxResponse = MessageBox.Show("One or more of the tables exists already. Do you want to delete them?", "Table Exists Message", MessageBoxButtons.YesNo);

                    if (msgBoxResponse == DialogResult.Yes)
                    {
                        id.DropTables();

                    }
                }
         
                // do not overwrite existing tables/data
                if (id.HouseTableExists)
                {
                    Console.WriteLine("ERROR: House table for this extract already exists and will not be overwritten.");
                    return;
                }
                if (id.PersonTableExists)
                {
                    Console.WriteLine("ERROR: Person table for this extract already exists and will not be overwritten.");
                    return;
                }

                try
                {
                    // process data 10,000 rows at a time
                    id.ProcessData(Convert.ToInt32(numBatch.Value));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("ERROR: Unable to process data.");
                    Console.WriteLine("ERROR: Exception: " + ex.Message);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: Unable to create IPUMS dataset.");
                Console.WriteLine("ERROR: Exception: " + ex.Message);
            }
        }

         
         */
    }
}
