﻿namespace Ipums
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tboxXml = new System.Windows.Forms.TextBox();
            this.btnSelectExtract = new System.Windows.Forms.Button();
            this.btnRun = new System.Windows.Forms.Button();
            this.lblXml = new System.Windows.Forms.Label();
            this.btnHelp = new System.Windows.Forms.Button();
            this.rtbConsole = new System.Windows.Forms.RichTextBox();
            this.tboxConnection = new System.Windows.Forms.TextBox();
            this.lblConnection = new System.Windows.Forms.Label();
            this.numBatch = new System.Windows.Forms.NumericUpDown();
            this.lblBatch = new System.Windows.Forms.Label();
            this.usePostGres_checkBox = new System.Windows.Forms.CheckBox();
            this.autoDeleteExistingTablesCheckBox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numBatch)).BeginInit();
            this.SuspendLayout();
            // 
            // tboxXml
            // 
            this.tboxXml.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxXml.Location = new System.Drawing.Point(109, 14);
            this.tboxXml.Name = "tboxXml";
            this.tboxXml.Size = new System.Drawing.Size(627, 20);
            this.tboxXml.TabIndex = 2;
            // 
            // btnSelectExtract
            // 
            this.btnSelectExtract.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectExtract.Location = new System.Drawing.Point(742, 12);
            this.btnSelectExtract.Name = "btnSelectExtract";
            this.btnSelectExtract.Size = new System.Drawing.Size(30, 23);
            this.btnSelectExtract.TabIndex = 3;
            this.btnSelectExtract.Text = "...";
            this.btnSelectExtract.UseVisualStyleBackColor = true;
            this.btnSelectExtract.Click += new System.EventHandler(this.SelectExtract);
            // 
            // btnRun
            // 
            this.btnRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRun.Location = new System.Drawing.Point(697, 351);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 7;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.OnRun);
            // 
            // lblXml
            // 
            this.lblXml.AutoSize = true;
            this.lblXml.Location = new System.Drawing.Point(12, 17);
            this.lblXml.Name = "lblXml";
            this.lblXml.Size = new System.Drawing.Size(75, 13);
            this.lblXml.TabIndex = 8;
            this.lblXml.Text = "DDI File (.xml):";
            // 
            // btnHelp
            // 
            this.btnHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnHelp.Location = new System.Drawing.Point(12, 351);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(75, 23);
            this.btnHelp.TabIndex = 7;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.OnRun);
            // 
            // rtbConsole
            // 
            this.rtbConsole.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbConsole.Location = new System.Drawing.Point(12, 112);
            this.rtbConsole.Name = "rtbConsole";
            this.rtbConsole.Size = new System.Drawing.Size(760, 233);
            this.rtbConsole.TabIndex = 9;
            this.rtbConsole.Text = "";
            // 
            // tboxConnection
            // 
            this.tboxConnection.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxConnection.Location = new System.Drawing.Point(109, 40);
            this.tboxConnection.Name = "tboxConnection";
            this.tboxConnection.Size = new System.Drawing.Size(627, 20);
            this.tboxConnection.TabIndex = 10;
            // 
            // lblConnection
            // 
            this.lblConnection.AutoSize = true;
            this.lblConnection.Location = new System.Drawing.Point(12, 43);
            this.lblConnection.Name = "lblConnection";
            this.lblConnection.Size = new System.Drawing.Size(94, 13);
            this.lblConnection.TabIndex = 8;
            this.lblConnection.Text = "Connection String:";
            // 
            // numBatch
            // 
            this.numBatch.Enabled = false;
            this.numBatch.Location = new System.Drawing.Point(109, 66);
            this.numBatch.Name = "numBatch";
            this.numBatch.Size = new System.Drawing.Size(79, 20);
            this.numBatch.TabIndex = 11;
            this.numBatch.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numBatch.ThousandsSeparator = true;
            this.numBatch.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Location = new System.Drawing.Point(12, 68);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(59, 13);
            this.lblBatch.TabIndex = 8;
            this.lblBatch.Text = "Batch size:";
            // 
            // usePostGres_checkBox
            // 
            this.usePostGres_checkBox.AutoSize = true;
            this.usePostGres_checkBox.Location = new System.Drawing.Point(537, 67);
            this.usePostGres_checkBox.Name = "usePostGres_checkBox";
            this.usePostGres_checkBox.Size = new System.Drawing.Size(150, 17);
            this.usePostGres_checkBox.TabIndex = 12;
            this.usePostGres_checkBox.Text = "use PostgreSQL database";
            this.usePostGres_checkBox.UseVisualStyleBackColor = true;
            // 
            // autoDeleteExistingTablesCheckBox
            // 
            this.autoDeleteExistingTablesCheckBox.AutoSize = true;
            this.autoDeleteExistingTablesCheckBox.Location = new System.Drawing.Point(537, 90);
            this.autoDeleteExistingTablesCheckBox.Name = "autoDeleteExistingTablesCheckBox";
            this.autoDeleteExistingTablesCheckBox.Size = new System.Drawing.Size(235, 17);
            this.autoDeleteExistingTablesCheckBox.TabIndex = 13;
            this.autoDeleteExistingTablesCheckBox.Text = "automatically delete existing database tables";
            this.autoDeleteExistingTablesCheckBox.UseVisualStyleBackColor = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 382);
            this.Controls.Add(this.autoDeleteExistingTablesCheckBox);
            this.Controls.Add(this.usePostGres_checkBox);
            this.Controls.Add(this.numBatch);
            this.Controls.Add(this.tboxConnection);
            this.Controls.Add(this.rtbConsole);
            this.Controls.Add(this.lblBatch);
            this.Controls.Add(this.lblConnection);
            this.Controls.Add(this.lblXml);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.btnSelectExtract);
            this.Controls.Add(this.tboxXml);
            this.MinimumSize = new System.Drawing.Size(525, 215);
            this.Name = "Main";
            this.Text = "IPUMS SQL Extact Tool";
            ((System.ComponentModel.ISupportInitialize)(this.numBatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

				private System.Windows.Forms.TextBox tboxXml;
				private System.Windows.Forms.Button btnSelectExtract;
				private System.Windows.Forms.Button btnRun;
				private System.Windows.Forms.Label lblXml;
				private System.Windows.Forms.Button btnHelp;
				private System.Windows.Forms.RichTextBox rtbConsole;
				private System.Windows.Forms.TextBox tboxConnection;
				private System.Windows.Forms.Label lblConnection;
				private System.Windows.Forms.NumericUpDown numBatch;
				private System.Windows.Forms.Label lblBatch;
                private System.Windows.Forms.CheckBox usePostGres_checkBox;
                private System.Windows.Forms.CheckBox autoDeleteExistingTablesCheckBox;
    }
}

