﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;


namespace Ipums
{
	public class Variable
	{
		public string Name { get; set; }
		public string Label { get; set; }
		public string Text { get; set; }
		public string Type { get; set; }

		public Dictionary<string, string> ValueLabels;

		public int ColumnStart { get; set; }
		public int Width { get; set; }

		public Variable()
		{
		}

		public Variable(string name, string label, Dictionary<string, string> values, string type, int columnStart, int width)
		{
			Name = name;
			Label = label;
			Type = type;
			ColumnStart = columnStart;
			Width = width;
		}

		/// <summary>
		/// Converts an IPUMS variable to a data column schema.
		/// </summary>
		public DataColumn ToDataColumn()
		{
			// default type for all variables
			Type t = typeof(int);

			// rectype however is a 1 char string
			if (Name == "RECTYPE" || Name == "RECTYPEP")
			{
				t = typeof(string);
			}

			// and serial can exceed a 32 bit integer
			if (Name == "SERIAL" || Name == "SERIALP")
			{
				t = typeof(Int64);
			}


			return new DataColumn(Name, t);
		}
	}

	/// <summary>
	/// Represents an IPUMS sample.
	/// </summary>
	public class Sample
	{
		public string Country { get; set; }
		public string CountryAbbreviation { get; set; }
		public int Year { get; set; }

		/// <summary>
		/// Create an IPUMS sample.
		/// </summary>
		/// <param name="country">Name of country contained in sample.</param>
		/// <param name="countryAbbreviation">Abbreviation for country.</param>
		/// <param name="year">Year of sample.</param>
		public Sample(string country, string countryAbbreviation, int year)
		{
			Country = country;
			CountryAbbreviation = countryAbbreviation;
			Year = year;
		}
	}


	public enum ExtractFormat
	{
		Rectangular,
		Hierarchical
	}


	/// <summary>
	/// Represents an IPUMS extract, containing one or more samples.
	/// </summary>
	public class Extract
	{
		public string XmlFilename { get; set; }

		public List<Sample> Samples { get; set; }
		public bool MultiCountry { get; set; }

		public string ExtractFilename { get; set; }
		public ExtractFormat Format { get; set; }

		public List<Variable> HouseVariables { get; set; }
		public List<Variable> PersonVariables { get; set; }

		public string HouseTableName { get; set; }
		public string PersonTableName { get; set; }
		public string MetaTableName = "variablevalues";

		/// <summary>
		/// Create an IPUMS extract based off DDI file.
		/// </summary>
		/// <param name="xmlFilename">Filename of DDI file.</param>
		public Extract(string xmlFilename)
		{
			XmlFilename = xmlFilename;

			Samples = new List<Sample>();

			HouseVariables = new List<Variable>();
			PersonVariables = new List<Variable>();

			ParseXml();
		}

		/// <summary>
		/// Parses DDI file.
		/// </summary>
		private void ParseXml()
		{
			Console.WriteLine("Opening DDI file.");
			XDocument xd = XDocument.Load(XmlFilename);
			Console.WriteLine("Parsing DDI file.");

			XElement codebook = xd.Root;
			XNamespace ns = codebook.GetDefaultNamespace();

			// samples
			Console.WriteLine("Reading samples.");
			var samples = codebook.Element(ns + "stdyDscr").Element(ns + "stdyInfo").Elements(ns + "sumDscr");
			foreach (XElement s in samples)
			{
				string country = s.Element(ns + "nation").Value;
                country = Regex.Replace(country, @"\s+", "");
				string countryAbbreviation = s.Element(ns + "nation").Attribute("abbr").Value;
				int year = Convert.ToInt32(s.Element(ns + "timePrd").Value);

				Samples.Add(new Sample(country, countryAbbreviation, year));
			}
			Console.WriteLine("Found " + Samples.Count + " samples.");

			// filename and structure
			Console.WriteLine("Reading extract information.");
			XElement fileTxt = codebook.Element(ns + "fileDscr").Element(ns + "fileTxt");
			ExtractFilename = Path.Combine(Path.GetDirectoryName(XmlFilename), fileTxt.Element(ns + "fileName").Value);
			string structure = fileTxt.Element(ns + "fileStrc").Attribute("type").Value;
			if (structure == "hierarchical")
				Format = ExtractFormat.Hierarchical;
			else if (structure == "rectangular")
				Format = ExtractFormat.Rectangular;
			else
				throw new Exception("Unknown extract format");
			Console.WriteLine("Extract located at: " + ExtractFilename);
			Console.WriteLine("Extract is in " + Format.ToString().ToLower() + " format.");

			// craft table names
			string tableBase;
			if (Samples.Count > 1)
			{
				MultiCountry = true;
				tableBase = Path.GetFileNameWithoutExtension(ExtractFilename);
			}
			else
			{
				tableBase = Samples[0].Country + Samples[0].Year;
			}
			HouseTableName = tableBase + "Houses";
			PersonTableName = tableBase + "Persons";
			Console.WriteLine("Table " + HouseTableName + " will be created for house data.");
			Console.WriteLine("Table " + PersonTableName + " will be created for person data.");

			// variables
			XElement dataDescription = codebook.Element(ns + "dataDscr");
			var houseElements = from el in dataDescription.Elements()
													where el.Name == ns + "var" & el.Attribute("rectype").Value.Contains("H")
													select el;
			foreach (XElement xe in houseElements)
			{
				// parse values and labels
				string name = xe.Attribute("ID").Value;
				string label = xe.Element(ns + "labl").Value;
				string type = "H";

				IEnumerable<KeyValuePair<string, string>> values = from el in xe.Elements()
																													 where el.Name == ns + "catgry"
																													 select new KeyValuePair<string, string>(el.Element(ns + "catValu").Value,
																																																	 el.Element(ns + "labl").Value);

				Dictionary<string, string> valuesAndLabels = new Dictionary<string, string>(values.Count());
				foreach (var v in values)
				{
					valuesAndLabels.Add(v.Key, v.Value);
				}

				var location = xe.Element(ns + "location");
				int colStart = Convert.ToInt32(location.Attribute("StartPos").Value);
				int width = Convert.ToInt32(location.Attribute("width").Value);

				HouseVariables.Add(new Variable(name, label, valuesAndLabels, type, colStart, width));
			}
			Console.WriteLine("Found " + HouseVariables.Count + " house variables.");

			var personElements = from el in dataDescription.Elements()
													 where el.Name == ns + "var" & el.Attribute("rectype").Value.Contains("P")
													 select el;
			foreach (XElement xe in personElements)
			{
				// parse values and labels
				string name = xe.Attribute("ID").Value;
				string label = xe.Element(ns + "labl").Value;
				string type = "P";

				IEnumerable<KeyValuePair<string, string>> values = from el in xe.Elements()
																													 where el.Name == ns + "catgry"
																													 select new KeyValuePair<string, string>(el.Element(ns + "catValu").Value,
																																																	 el.Element(ns + "labl").Value);

				Dictionary<string, string> valuesAndLabels = new Dictionary<string, string>(values.Count());
				foreach (var v in values)
				{
					valuesAndLabels.Add(v.Key, v.Value);
				}

				var location = xe.Element(ns + "location");
				int colStart = Convert.ToInt32(location.Attribute("StartPos").Value);
				int width = Convert.ToInt32(location.Attribute("width").Value);

				PersonVariables.Add(new Variable(name, label, valuesAndLabels, type, colStart, width));
			}
			Console.WriteLine("Found " + PersonVariables.Count + " person variables.");
			Console.WriteLine("Finished parsing DDI file.");

            // ICW 28/1/2016
            // Sort lists by column start so they are in the correct order
            PersonVariables.Sort((x, y) => x.ColumnStart.CompareTo(y.ColumnStart));
            HouseVariables.Sort((x, y) => x.ColumnStart.CompareTo(y.ColumnStart));
            
		}

		/// <summary>
		/// Get SQL to create house table.
		/// </summary>
		public string GetHouseSql(bool useODBCConnection=false)
		{
            StringBuilder sb = new StringBuilder();

            if (!useODBCConnection)
            {
               
                sb.Append("CREATE TABLE ");
                sb.Append(HouseTableName);
                sb.Append(" (");
                sb.AppendLine();

                // fields
                foreach (Variable v in HouseVariables)
                {
                    sb.Append("\t");
                    sb.Append(v.Name);
                    sb.AppendLine(" int NULL,");
                }

                // primary key
                sb.Append("\tCONSTRAINT PK_");
                sb.Append(HouseTableName);
                sb.AppendLine(" PRIMARY KEY CLUSTERED (SAMPLE ASC, SERIAL ASC)");
                sb.AppendLine(")");

                // fix rectype and pk
                sb.Replace("RECTYPE int", "RECTYPE char(1)");
                sb.Replace("SAMPLE int NULL", "SAMPLE int NOT NULL");
                sb.Replace("SERIAL int NULL", "SERIAL bigint NOT NULL");
            }
            else
            {
                // this is Postgres
                sb.Append("CREATE TABLE ");
                sb.Append(HouseTableName);
                sb.Append(" (");
                sb.AppendLine();

                // fields
                foreach (Variable v in HouseVariables)
                {
                    sb.Append("\t");
                    sb.Append(v.Name);
                    sb.AppendLine(" int NULL,");
                }

                // primary key
                sb.Append("\tCONSTRAINT PK_");
               sb.Append(HouseTableName);
               
               sb.AppendLine(" PRIMARY KEY (SAMPLE, SERIAL)");
                
                sb.AppendLine(")");

                // fix rectype and pk
                sb.Replace("RECTYPE int", "RECTYPE char(1)");
                sb.Replace("SAMPLE int NULL", "SAMPLE int NOT NULL");
                sb.Replace("SERIAL int NULL", "SERIAL bigint NOT NULL");
            }
			return sb.ToString();
		}

		/// <summary>
		/// Get SQL to create person table.
		/// </summary>
        public string GetPersonSql(bool useODBCConnection = false)
		{
			StringBuilder sb = new StringBuilder();

            if (!useODBCConnection)
            {
                sb.Append("CREATE TABLE ");
                sb.Append(PersonTableName);
                sb.Append(" (");
                sb.AppendLine();

                // fields
                foreach (Variable v in PersonVariables)
                {
                    sb.Append("\t");
                    sb.Append(v.Name);
                    sb.AppendLine(" int NULL,");
                }

                // primary key
                sb.Append("\tCONSTRAINT PK_");
                sb.Append(PersonTableName);
                sb.AppendLine(" PRIMARY KEY CLUSTERED ( SAMPLE ASC, SERIAL ASC, PERNUM ASC ),");

                // foreign key
                sb.Append("\tCONSTRAINT fk_");
                sb.Append(PersonTableName);
                sb.Append("_");
                sb.AppendLine(HouseTableName);
                sb.AppendLine("\tFOREIGN KEY(SAMPLE,SERIAL)");
                sb.Append("\tREFERENCES ");
                sb.Append(HouseTableName);
                sb.AppendLine(" (SAMPLE,SERIAL)");
                sb.AppendLine(")");

                // fix rectype, pk, and fk
                sb.Replace("RECTYPE int", "RECTYPE char(1)");
                sb.Replace("SAMPLE int NULL", "SAMPLE int NOT NULL");
                sb.Replace("SERIAL int NULL", "SERIAL bigint NOT NULL");
                sb.Replace("PERNUM int NULL", "PERNUM int NOT NULL");
            }
            else
            {
                // postgres
                sb.Append("CREATE TABLE ");
                sb.Append(PersonTableName);
                sb.Append(" (");
                sb.AppendLine();

                // fields
                foreach (Variable v in PersonVariables)
                {
                    sb.Append("\t");
                    sb.Append(v.Name);
                    sb.AppendLine(" int NULL,");
                }

                // primary key
                sb.Append("\tCONSTRAINT PK_");
                sb.Append(PersonTableName);
              
                sb.AppendLine(" PRIMARY KEY  ( SAMPLE , SERIAL , PERNUM  ),");

                // foreign key
                sb.Append("\tCONSTRAINT fk_");
                sb.Append(PersonTableName);
                sb.Append("_");
                sb.AppendLine(HouseTableName);
                sb.AppendLine("\tFOREIGN KEY(SAMPLE,SERIAL)");
                sb.Append("\tREFERENCES ");
                sb.Append(HouseTableName);
                sb.AppendLine(" (SAMPLE,SERIAL)");
                sb.AppendLine(")");

                // fix rectype, pk, and fk
                sb.Replace("RECTYPE int", "RECTYPE char(1)");
                sb.Replace("SAMPLE int NULL", "SAMPLE int NOT NULL");
                sb.Replace("SERIAL int NULL", "SERIAL bigint NOT NULL");
                sb.Replace("PERNUM int NULL", "PERNUM int NOT NULL");
            }

			return sb.ToString();
		}

		/// <summary>
		/// Get SQL to create meta table.
		/// </summary>
        public string GetMetaSql(bool useODBCConnection = false)
		{
			StringBuilder sb = new StringBuilder();

            if (!useODBCConnection)
            {
                sb.Append("CREATE TABLE ");
                sb.Append(MetaTableName);
                sb.Append(" (");
                sb.AppendLine();

                // fields
                sb.AppendLine("\tTableName nvarchar(50) NOT NULL,");
                sb.AppendLine("\tField nvarchar(50) NOT NULL,");
                sb.AppendLine("\tValue int NOT NULL,");
                sb.AppendLine("\tLabel nvarchar(50) NOT NULL,");

                // primary key
                sb.Append("\tCONSTRAINT PK_");
                sb.Append(MetaTableName);
                sb.AppendLine(" PRIMARY KEY CLUSTERED");
                sb.AppendLine("\t(");
                sb.AppendLine("\t\tTableName ASC,");
                sb.AppendLine("\t\tField ASC,");
                sb.AppendLine("\t\tValue ASC");
                sb.AppendLine("\t)");

                sb.AppendLine(")");

            }
            else
            {
                // postgres
                sb.Append("CREATE TABLE ");
                sb.Append(MetaTableName);
                sb.Append(" (");
                sb.AppendLine();

                // fields
                sb.AppendLine("\tTableName nvarchar(50) NOT NULL,");
                sb.AppendLine("\tField nvarchar(50) NOT NULL,");
                sb.AppendLine("\tValue int NOT NULL,");
                sb.AppendLine("\tLabel nvarchar(50) NOT NULL,");

                // primary key
                sb.Append("\tCONSTRAINT PK_");
                sb.Append(MetaTableName);
                //sb.AppendLine(" PRIMARY KEY CLUSTERED");
                sb.AppendLine(" PRIMARY KEY ");
                sb.AppendLine("\t(");
                /*sb.AppendLine("\t\tTableName ASC,");
                sb.AppendLine("\t\tField ASC,");
                sb.AppendLine("\t\tValue ASC"); */
                sb.AppendLine("\t\tTableName ,");
                sb.AppendLine("\t\tField ,");
                sb.AppendLine("\t\tValue ");
                sb.AppendLine("\t)");

                sb.AppendLine(")");

                // postgres doesn't have nvarchar which is unicode related
                sb.Replace("nvarchar", "varchar");

            }
			return sb.ToString();
		}
	}
}
