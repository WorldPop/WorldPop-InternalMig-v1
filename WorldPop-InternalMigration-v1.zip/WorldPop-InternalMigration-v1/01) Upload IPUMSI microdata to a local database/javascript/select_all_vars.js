// javascript snippet that will select all IPUMS variables for an extract
//
// Not garuanteed to work if IPUMS changes their website functionality. Look at the js scripts that are loaded
// and search for the functions that might have changed (addRemoveVariable, etc.)
//
// To use this:
// 1. Select a sample
// 2. Set options to list all variables at once versus by group
// 3. Open Chrome's Javascript Console (Ctrl+Shift+J) (or perhaps use Firebug if using Firefox
// 4. Copy and paste the code below
//
//


// manual attempt
addRemoveAllInGroup('h-tech', true);
addRemoveAllInGroup('h-gq', true);
addRemoveAllInGroup('h-geog', true);
addRemoveAllInGroup('h-econ', true);
addRemoveAllInGroup('h-util', true);
addRemoveAllInGroup('h-app', true);
addRemoveAllInGroup('h-dwell', true);
addRemoveAllInGroup('h-other', true);
addRemoveAllInGroup('h-cons', true);
addRemoveAllInGroup('tech', true);
addRemoveAllInGroup('cons', true);
addRemoveAllInGroup('core', true);
addRemoveAllInGroup('fert', true);
addRemoveAllInGroup('nativ', true);
addRemoveAllInGroup('ethnic', true);
addRemoveAllInGroup('educ', true);
addRemoveAllInGroup('work', true);
addRemoveAllInGroup('inc', true);
addRemoveAllInGroup('mig', true);
addRemoveAllInGroup('dis', true);



// semi automated with pause
// REMOVE groups not in the sample, commonly these are groups with small number of vars
// such as 'inc'
var groups = [
'h-tech',
'h-gq',
'h-geog',
'h-econ',
'h-util',
'h-app',
'h-dwell',
'h-other',
'h-cons',
'tech',
'cons',
'core',
'fert',
'nativ',
'ethnic',
'educ',
'work',
//'inc',
'mig',
'dis'];

function pause(millis)
 {
  var date = new Date();
  var curDate = null;
  do { curDate = new Date(); }
  while(curDate-date < millis);
}

for (var i=0; i < groups.length; i++) {
	try {
		console.log("Adding " + groups[i]);
		console.log("Waiting...");
		pause(2000)
		addRemoveAllInGroup(groups[i], true);
		
	}
	catch (err) {
		console.log("Continuing");
		//console.log(err)
	}
}
pause(1000);

