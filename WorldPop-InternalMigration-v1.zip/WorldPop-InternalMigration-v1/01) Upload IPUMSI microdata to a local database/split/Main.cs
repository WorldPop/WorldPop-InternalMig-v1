﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace hier_split
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void SelectFile(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() != DialogResult.Cancel) {
                tboxFilename.Text = ofd.FileName;
            }
        }

        private void OnRun(object sender, EventArgs e)
        {
            // check if file exists
            String datFilename = tboxFilename.Text;
            FileInfo fi = new FileInfo(datFilename);
            if (!fi.Exists)
            {
                MessageBox.Show("File does not exist.");
                return;
            }

            // craft output filenames
            String path = fi.FullName;
            String houseFilename = Path.GetFileNameWithoutExtension(fi.FullName) + "-Houses.dat";
            houseFilename = Path.Combine(fi.DirectoryName, houseFilename);
            String personFilename = Path.GetFileNameWithoutExtension(fi.FullName) + "-Persons.dat";
            personFilename = Path.Combine(fi.DirectoryName, personFilename);

            // open output files
            if (File.Exists(houseFilename))
            {
                if (MessageBox.Show("House filename already exists. Overwrite?", "Overwrite existing house data?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.No)
                {
                    return;
                }
            }

            // open output files
            if (File.Exists(personFilename))
            {
                if (MessageBox.Show("Person filename already exists. Overwrite?", "Overwrite existing person data?",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.No)
                {
                    return;
                }
            }

            // open input and output files
            StreamReader datFile = new StreamReader(datFilename);
            StreamWriter houseFile = new StreamWriter(houseFilename);
            StreamWriter personFile = new StreamWriter(personFilename);
            String s;
            int i = 0;
            
            // process each line in dat file
            while ((s = datFile.ReadLine()) != null)
            {
                // track line number for error reporting
                i++;

                // based off first character, place in either house file or person file
                if (s.StartsWith("H"))
                {
                    houseFile.WriteLine(s);
                }
                else if (s.StartsWith("P"))
                {
                    personFile.WriteLine(s);
                }
                else
                {
                    // problem...
                    MessageBox.Show("Error in line " + i + ".  LineRecord does not begin with H or P");
                    return;
                }
            }

            MessageBox.Show("Finished processing " + i + " lines of data");
            datFile.Close();
            houseFile.Close();
            personFile.Close();
        }
    }
}
