﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;
using System.Linq;
using System.Text;

namespace Ipums
{
	class Program
	{
		static void Main(string[] args)
		{



			Console.WriteLine("Finished");
		}
	}
}
