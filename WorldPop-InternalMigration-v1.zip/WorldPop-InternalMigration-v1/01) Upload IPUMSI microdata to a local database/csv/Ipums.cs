﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ipums
{
    public abstract class Variable
    {
        public string Name { get; set; }
        public int ColumnStart { get; set; }
        public int ColumnEnd { get; set; }
        public int Length { get; set; }

        public Variable(string name, string columns, string length)
        {
            Name = name;

            string[] ss = columns.Split('-');
            if (ss.Count() == 1)
            {
                // single column variable
                ColumnStart = Convert.ToInt32(columns);
                ColumnEnd = ColumnStart;

            }
            else
            {
                ColumnStart = Convert.ToInt32(ss[0]);
                ColumnEnd = Convert.ToInt32(ss[1]);
            }

            Length = Convert.ToInt32(length);
        }
    }

    public class HouseVariable : Variable
    {
        public HouseVariable( string name, string columns, string length ) : base( name, columns, length )
        {

        }
    }


    public class PersonVariable : Variable
    {
        public PersonVariable( string name, string columns, string length ) : base( name, columns, length )
        {

        }
    }

    public class IpumsParser
    {
        public string DatFilename { get; set; }
        public string CodebookFilename { get; set; }

        public string HouseFilename { get; set; }
        public string PersonFilename { get; set; }

        public Dictionary<int,HouseVariable> HouseVariables { get; set; }
        public Dictionary<int,PersonVariable> PersonVariables { get; set; }

        public IpumsParser( string datFilename, string codebookFilename )
        {
            DatFilename = datFilename;
            CodebookFilename = codebookFilename;

            String datDirectory = Path.GetDirectoryName(DatFilename);
            HouseFilename = Path.GetFileNameWithoutExtension(datFilename) + "-Houses.csv";
            HouseFilename = Path.Combine(datDirectory, HouseFilename);
            PersonFilename = Path.GetFileNameWithoutExtension(datFilename) + "-Persons.csv";
            PersonFilename = Path.Combine(datDirectory, PersonFilename);

            HouseVariables = new Dictionary<int, HouseVariable>();
            PersonVariables = new Dictionary<int, PersonVariable>();
        }

        public void ParseCodebook()
        {
            // open codebook
            StreamReader sr = new StreamReader(CodebookFilename);

            // read until file type line
            string s;
            while (!(s = sr.ReadLine()).StartsWith("File Type:")) { }

            // ensure we are using hierarchical data
            string[] ss = s.Split(new char[] { ' ', ':' }, StringSplitOptions.RemoveEmptyEntries);
            if (ss[2] != "hierarchical")
            {
                // problems...
            }

            // read until variable header line
            while (!sr.ReadLine().StartsWith("  Variable")) { }

            // parse each variable
            while (!String.IsNullOrEmpty(s = sr.ReadLine()))
            {
                ss = s.Split(null as char[], StringSplitOptions.RemoveEmptyEntries);

                string name = ss[0];
                string type = ss[1];
                string cols = ss[2];
                string len = ss[3];

                if (type == "H")
                {
                    HouseVariable hv = new HouseVariable(name, cols, len);
                    HouseVariables.Add(HouseVariables.Count, hv);

                }
                else if (type == "P")
                {
                    PersonVariable pv = new PersonVariable(name, cols, len);
                    PersonVariables.Add(PersonVariables.Count, pv);
                }
            }

            // finished, rest of file is not needed
            sr.Close();
        }

        public int ProcessData()
        {
            // input, output, and csv streams
            StreamReader datFile = new StreamReader(DatFilename);
            StreamWriter houseFile = new StreamWriter(HouseFilename);
            StreamWriter personFile = new StreamWriter(PersonFilename);
            StringBuilder csv = new StringBuilder();


            // write house headers
            csv.Clear();
            for( int i = 0; i < HouseVariables.Count; ++i ) {
                csv.Append( HouseVariables[i].Name + "," );
            }
            csv.Remove( csv.Length - 1, 1 );
            houseFile.WriteLine( csv.ToString() );
            houseFile.Flush();

            // write person headers
            csv.Clear();
            for( int i = 0; i < PersonVariables.Count; ++i ) {
                csv.Append( PersonVariables[i].Name + "," );
            }
            // clear last comma
            csv.Remove( csv.Length - 1, 1 );
            personFile.WriteLine( csv.ToString() );


            // process each line in dat file
            String s;
            int lines = 0;

            while ((s = datFile.ReadLine()) != null)
            {
                // track line number for error reporting
                lines++;

                // based off first character, place in either house file or person file
                if (s.StartsWith("H"))
                {
                    csv.Clear();
                    for( int i = 0; i < HouseVariables.Count; ++i ) {
                        csv.Append(s, HouseVariables[i].ColumnStart-1, HouseVariables[i].Length);
                        csv.Append(",");
                    }
                    csv.Remove(csv.Length - 1, 1);
                    houseFile.WriteLine(csv.ToString());
                }
                else if (s.StartsWith("P"))
                {
                    csv.Clear();
                    for( int i = 0; i < PersonVariables.Count; ++i ) {
                        csv.Append(s, PersonVariables[i].ColumnStart-1, PersonVariables[i].Length);
                        csv.Append(",");
                    }
                    csv.Remove(csv.Length - 1, 1);
                    personFile.WriteLine(csv.ToString());
                }
                else
                {
                    throw new InvalidDataException( "Record at line " + lines + " does not begin with an H or P." );
                }
            }

            datFile.Close();
            houseFile.Close();
            personFile.Close();

            return lines;
        }
    }
}
