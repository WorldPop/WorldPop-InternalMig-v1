﻿namespace hier_to_csv
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.tboxDat = new System.Windows.Forms.TextBox();
            this.lblDat = new System.Windows.Forms.Label();
            this.btnSelectDat = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.btnSelectCookbook = new System.Windows.Forms.Button();
            this.tboxCodebook = new System.Windows.Forms.TextBox();
            this.lblCookbook = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tboxDat
            // 
            this.tboxDat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxDat.Location = new System.Drawing.Point(69, 188);
            this.tboxDat.Name = "tboxDat";
            this.tboxDat.Size = new System.Drawing.Size(392, 20);
            this.tboxDat.TabIndex = 2;
            // 
            // lblDat
            // 
            this.lblDat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDat.AutoSize = true;
            this.lblDat.Location = new System.Drawing.Point(12, 191);
            this.lblDat.Name = "lblDat";
            this.lblDat.Size = new System.Drawing.Size(51, 13);
            this.lblDat.TabIndex = 1;
            this.lblDat.Text = ".DAT file:";
            // 
            // btnSelectDat
            // 
            this.btnSelectDat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectDat.Location = new System.Drawing.Point(467, 186);
            this.btnSelectDat.Name = "btnSelectDat";
            this.btnSelectDat.Size = new System.Drawing.Size(30, 23);
            this.btnSelectDat.TabIndex = 3;
            this.btnSelectDat.Text = "...";
            this.btnSelectDat.UseVisualStyleBackColor = true;
            this.btnSelectDat.Click += new System.EventHandler(this.SelectDat);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.richTextBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.MinimumSize = new System.Drawing.Size(0, 130);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(485, 166);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Usage";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox1.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Location = new System.Drawing.Point(6, 19);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(473, 141);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // btnRun
            // 
            this.btnRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRun.Location = new System.Drawing.Point(422, 244);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 7;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.OnRun);
            // 
            // btnSelectCookbook
            // 
            this.btnSelectCookbook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectCookbook.Location = new System.Drawing.Point(467, 215);
            this.btnSelectCookbook.Name = "btnSelectCookbook";
            this.btnSelectCookbook.Size = new System.Drawing.Size(30, 23);
            this.btnSelectCookbook.TabIndex = 6;
            this.btnSelectCookbook.Text = "...";
            this.btnSelectCookbook.UseVisualStyleBackColor = true;
            this.btnSelectCookbook.Click += new System.EventHandler(this.SelectCodebookFile);
            // 
            // tboxCodebook
            // 
            this.tboxCodebook.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tboxCodebook.Location = new System.Drawing.Point(69, 214);
            this.tboxCodebook.Name = "tboxCodebook";
            this.tboxCodebook.Size = new System.Drawing.Size(392, 20);
            this.tboxCodebook.TabIndex = 5;
            // 
            // lblCookbook
            // 
            this.lblCookbook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblCookbook.AutoSize = true;
            this.lblCookbook.Location = new System.Drawing.Point(12, 217);
            this.lblCookbook.Name = "lblCookbook";
            this.lblCookbook.Size = new System.Drawing.Size(50, 13);
            this.lblCookbook.TabIndex = 4;
            this.lblCookbook.Text = ".CBK file:";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(509, 279);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSelectCookbook);
            this.Controls.Add(this.btnSelectDat);
            this.Controls.Add(this.lblCookbook);
            this.Controls.Add(this.lblDat);
            this.Controls.Add(this.tboxCodebook);
            this.Controls.Add(this.tboxDat);
            this.MinimumSize = new System.Drawing.Size(525, 215);
            this.Name = "Main";
            this.Text = "IPUMS Hierachical to CSV Converter";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tboxDat;
        private System.Windows.Forms.Label lblDat;
        private System.Windows.Forms.Button btnSelectDat;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Button btnSelectCookbook;
        private System.Windows.Forms.TextBox tboxCodebook;
        private System.Windows.Forms.Label lblCookbook;
    }
}

