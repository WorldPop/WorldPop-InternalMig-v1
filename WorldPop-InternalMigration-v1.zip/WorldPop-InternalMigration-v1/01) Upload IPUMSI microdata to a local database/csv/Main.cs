﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Ipums;

namespace hier_to_csv
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void SelectDat(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() != DialogResult.Cancel)
            {
                // use selected file
                String filename = ofd.FileName;
                tboxDat.Text = filename;

                // let's guess the codebook filename
                String codebookFilename = Path.GetFileNameWithoutExtension(filename) + ".cbk";
                String dir = Path.GetDirectoryName(filename);
                codebookFilename = Path.Combine(dir, codebookFilename);

                // and set the selection
                if (File.Exists(codebookFilename))
                {
                    tboxCodebook.Text = codebookFilename;
                }

            }
        }

        private void SelectCodebookFile(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() != DialogResult.Cancel)
            {
                tboxCodebook.Text = ofd.FileName;
            }
        }

        private void OnRun(object sender, EventArgs e)
        {
            // check that dat and codebook exist
            String datFilename = tboxDat.Text;
            if (!File.Exists(datFilename))
            {
                MessageBox.Show("Dat file does not exist.");
                return;
            }
            String codebookFilename = tboxCodebook.Text;
            if (!File.Exists(codebookFilename))
            {
                MessageBox.Show("Codebook file does not exist.");
                return;
            }

            // create ipums parser
            IpumsParser ip = new IpumsParser(datFilename, codebookFilename);
            ip.ParseCodebook();
            ip.ProcessData();
        }



    }
}