// Projectver1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
using namespace std;


struct person{
	//int sample;  char IPUMS_sample_identifier [50];
    //int urban;   char Urban_rural_status [50];         
    int distug;  char District_cam [700];        
	//int cntyug;  char County_Uganda [50];        
	//int pernum;  
	//int age2;    char Age [50];     
	//int sex;     char Sex [50];      
	//int mgctry1; char Country_of_previous_residence [50];      
	int migug;   char District_camp [700];     
	//int mgyrs1;  char Years_residing_in_current_locality [50];      
};person p1 [1000000];
//person p2 [500000];
char temp [54];
string str,x,y,z,w,v,u,s;
char t [3];
int yrsinlocniuflag=0;
int main(int argc, char* argv[])
{
	ifstream in;
	in.open("g:\\ipumsi_00024.dat");
	if(!in)
	{
		cout<<"Couldn't open file";
		exit(1);
	}
	ofstream mfl;
  mfl.open ("g:\\out_viet.txt");
  if(!mfl)
	{
		cout<<"Couldn't open file";
		exit(1);
	}
	int i=0,m=0,flag=0;
	
	mfl<<"District_cam"<<";"<<"District_camp"<<"\n";
	
	while(!in.eof())
	{
		getline ( in, str, '\n' );

		y=str.substr(16,3);
if( !y.compare("110"))
{	p1[i].distug=110;
strcpy(p1[i].District_cam,"Ha Noi");}
if( !y.compare("120"))
{	p1[i].distug=120;
strcpy(p1[i].District_cam,"Hai Phong");}
if( !y.compare("130"))
{	p1[i].distug=130;
strcpy(p1[i].District_cam,"Ha Son Binh");}
if( !y.compare("140"))
{	p1[i].distug=140;
strcpy(p1[i].District_cam,"Hai Hung");}
if( !y.compare("141"))
{	p1[i].distug=141;
strcpy(p1[i].District_cam,"Hai Duong");}
if( !y.compare("142"))
{	p1[i].distug=142;
strcpy(p1[i].District_cam,"Hung Yen");}
if( !y.compare("150"))
{	p1[i].distug=150;
strcpy(p1[i].District_cam,"Thai Binh");}
if( !y.compare("160"))
{	p1[i].distug=160;
strcpy(p1[i].District_cam,"Ha Nam Ninh");}
if( !y.compare("161"))
{	p1[i].distug=161;
strcpy(p1[i].District_cam,"Ha Nam");}
if( !y.compare("162"))
{	p1[i].distug=162;
strcpy(p1[i].District_cam,"Nam Dinh");}
if( !y.compare("163"))
{	p1[i].distug=163;
strcpy(p1[i].District_cam,"Ninh Binh");}
if( !y.compare("210"))
{	p1[i].distug=210;
strcpy(p1[i].District_cam,"Ha Tuyen");}
if( !y.compare("211"))
{	p1[i].distug=211;
strcpy(p1[i].District_cam,"Ha Giang");}
if( !y.compare("212"))
{	p1[i].distug=212;
strcpy(p1[i].District_cam,"Tuyen Quang");}
if( !y.compare("220"))
{	p1[i].distug=220;
strcpy(p1[i].District_cam,"Cao Bang");}
if( !y.compare("230"))
{	p1[i].distug=230;
strcpy(p1[i].District_cam,"Lang Son");}
if( !y.compare("240"))
{	p1[i].distug=240;
strcpy(p1[i].District_cam,"Hoang Lien Son");}
if( !y.compare("241"))
{	p1[i].distug=241;
strcpy(p1[i].District_cam,"Lao Cai");}
if( !y.compare("242"))
{	p1[i].distug=242;
strcpy(p1[i].District_cam,"Yen Bai");}
if( !y.compare("250"))
{	p1[i].distug=250;
strcpy(p1[i].District_cam,"Bac Thai");}
if( !y.compare("251"))
{	p1[i].distug=251;
strcpy(p1[i].District_cam,"Bac Kan");}
if( !y.compare("252"))
{	p1[i].distug=252;
strcpy(p1[i].District_cam,"Thai Nguyen");}
if( !y.compare("260"))
{	p1[i].distug=260;
strcpy(p1[i].District_cam,"Vinh Phu");}
if( !y.compare("261"))
{	p1[i].distug=261;
strcpy(p1[i].District_cam,"Phu Tho");}
if( !y.compare("262"))
{	p1[i].distug=262;
strcpy(p1[i].District_cam,"Vinh Phuc");}
if( !y.compare("270"))
{	p1[i].distug=270;
strcpy(p1[i].District_cam,"Ha Bac");}
if( !y.compare("271"))
{	p1[i].distug=271;
strcpy(p1[i].District_cam,"Bac Giang");}
if( !y.compare("272"))
{	p1[i].distug=272;
strcpy(p1[i].District_cam,"Bac Ninh");}
if( !y.compare("280"))
{	p1[i].distug=280;
strcpy(p1[i].District_cam,"Quang Ninh");}
if( !y.compare("310"))
{	p1[i].distug=310;
strcpy(p1[i].District_cam,"Lai Chau");}
if( !y.compare("320"))
{	p1[i].distug=320;
strcpy(p1[i].District_cam,"Son La");}
if( !y.compare("321"))
{	p1[i].distug=321;
strcpy(p1[i].District_cam,"Son La");}
if( !y.compare("322"))
{	p1[i].distug=322;
strcpy(p1[i].District_cam,"Hoa Binh");}
if( !y.compare("410"))
{	p1[i].distug=410;
strcpy(p1[i].District_cam,"Thanh Hoa");}
if( !y.compare("420"))
{	p1[i].distug=420;
strcpy(p1[i].District_cam,"Nghe Tinh");}
if( !y.compare("421"))
{	p1[i].distug=421;
strcpy(p1[i].District_cam,"Nghe An");}
if( !y.compare("422"))
{	p1[i].distug=422;
strcpy(p1[i].District_cam,"Ha Tinh");}
if( !y.compare("430"))
{	p1[i].distug=430;
strcpy(p1[i].District_cam,"Quang Binh");}
if( !y.compare("440"))
{	p1[i].distug=440;
strcpy(p1[i].District_cam,"Quang Tri");}
if( !y.compare("450"))
{	p1[i].distug=450;
strcpy(p1[i].District_cam,"Thua Thien - Hue");}
if( !y.compare("510"))
{	p1[i].distug=510;
strcpy(p1[i].District_cam,"Quang Nam - Da Nang");}
if( !y.compare("511"))
{	p1[i].distug=511;
strcpy(p1[i].District_cam,"Da Nang");}
if( !y.compare("512"))
{	p1[i].distug=512;
strcpy(p1[i].District_cam,"Quang Nam");}
if( !y.compare("520"))
{	p1[i].distug=520;
strcpy(p1[i].District_cam,"Binh Dinh");}
if( !y.compare("530"))
{	p1[i].distug=530;
strcpy(p1[i].District_cam,"Quang Ngai");}
if( !y.compare("540"))
{	p1[i].distug=540;
strcpy(p1[i].District_cam,"Phu Yen");}
if( !y.compare("550"))
{	p1[i].distug=550;
strcpy(p1[i].District_cam,"Khanh Hoa");}
if( !y.compare("610"))
{	p1[i].distug=610;
strcpy(p1[i].District_cam,"Gia Lai - Kon Tum");}
if( !y.compare("611"))
{	p1[i].distug=611;
strcpy(p1[i].District_cam,"Kon Tum");}
if( !y.compare("612"))
{	p1[i].distug=612;
strcpy(p1[i].District_cam,"Gia Lai");}
if( !y.compare("620"))
{	p1[i].distug=620;
strcpy(p1[i].District_cam,"Dac Lac");}
if( !y.compare("710"))
{	p1[i].distug=710;
strcpy(p1[i].District_cam,"Thuan Hai");}
if( !y.compare("711"))
{	p1[i].distug=711;
strcpy(p1[i].District_cam,"Ninh Thuan");}
if( !y.compare("712"))
{	p1[i].distug=712;
strcpy(p1[i].District_cam,"Binh Thuan");}
if( !y.compare("720"))
{	p1[i].distug=720;
strcpy(p1[i].District_cam,"Lam Dong");}
if( !y.compare("730"))
{	p1[i].distug=730;
strcpy(p1[i].District_cam,"Ho Chi Minh City");}
if( !y.compare("740"))
{	p1[i].distug=740;
strcpy(p1[i].District_cam,"Song Be");}
if( !y.compare("741"))
{	p1[i].distug=741;
strcpy(p1[i].District_cam,"Binh Duong");}
if( !y.compare("742"))
{	p1[i].distug=742;
strcpy(p1[i].District_cam,"Binh Phuoc");}
if( !y.compare("750"))
{	p1[i].distug=750;
strcpy(p1[i].District_cam,"Tay Ninh");}
if( !y.compare("760"))
{	p1[i].distug=760;
strcpy(p1[i].District_cam,"Dong Nai");}
if( !y.compare("770"))
{	p1[i].distug=770;
strcpy(p1[i].District_cam,"Vung Tau - Con Dao");}
if( !y.compare("810"))
{	p1[i].distug=810;
strcpy(p1[i].District_cam,"Long An");}
if( !y.compare("820"))
{	p1[i].distug=820;
strcpy(p1[i].District_cam,"Dong Thap");}
if( !y.compare("830"))
{	p1[i].distug=830;
strcpy(p1[i].District_cam,"An Giang");}
if( !y.compare("840"))
{	p1[i].distug=840;
strcpy(p1[i].District_cam,"Tien Giang");}
if( !y.compare("850"))
{	p1[i].distug=850;
strcpy(p1[i].District_cam,"Ben Tre");}
if( !y.compare("860"))
{	p1[i].distug=860;
strcpy(p1[i].District_cam,"Cuu Long");}
if( !y.compare("861"))
{	p1[i].distug=861;
strcpy(p1[i].District_cam,"Vinh Long");}
if( !y.compare("862"))
{	p1[i].distug=862;
strcpy(p1[i].District_cam,"Tra Vinh");}
if( !y.compare("870"))
{	p1[i].distug=870;
strcpy(p1[i].District_cam,"Hau Giang");}
if( !y.compare("871"))
{	p1[i].distug=871;
strcpy(p1[i].District_cam,"Can Tho");}
if( !y.compare("872"))
{	p1[i].distug=872;
strcpy(p1[i].District_cam,"Soc Trang");}
if( !y.compare("880"))
{	p1[i].distug=880;
strcpy(p1[i].District_cam,"Kien Giang");}
if( !y.compare("890"))
{	p1[i].distug=890;
strcpy(p1[i].District_cam,"Minh Hai");}
if( !y.compare("891"))
{	p1[i].distug=891;
strcpy(p1[i].District_cam,"Bac Lieu");}
if( !y.compare("892"))
{	p1[i].distug=892;
strcpy(p1[i].District_cam,"Ca Mau");}




z=str.substr(44,3);
if( !z.compare("000"))
{strcpy(p1[i].District_camp,"NIU (not in universe)");yrsinlocniuflag=1;}
if( !z.compare("100"))
{strcpy(p1[i].District_camp,"Red River Delta");}
if( !z.compare("110"))
{strcpy(p1[i].District_camp,"Ha noi");}
if( !z.compare("120"))
{strcpy(p1[i].District_camp,"Hai Phong");}
if( !z.compare("130"))
{strcpy(p1[i].District_camp,"Ha Son Binh");}
if( !z.compare("140"))
{strcpy(p1[i].District_camp,"Hai Hung");}
if( !z.compare("141"))
{strcpy(p1[i].District_camp,"Hai Duong");}
if( !z.compare("142"))
{strcpy(p1[i].District_camp,"Hug Yen");}
if( !z.compare("150"))
{strcpy(p1[i].District_camp,"Thai Binh");}
if( !z.compare("160"))
{strcpy(p1[i].District_camp,"Ha Nam Ninh");}
if( !z.compare("161"))
{strcpy(p1[i].District_camp,"Ha Nam");}
if( !z.compare("162"))
{strcpy(p1[i].District_camp,"Nam Dinh");}
if( !z.compare("163"))
{strcpy(p1[i].District_camp,"Ninh Binh");}
if( !z.compare("200"))
{strcpy(p1[i].District_camp,"Northeast");}
if( !z.compare("210"))
{strcpy(p1[i].District_camp,"Ha Tuyen");}
if( !z.compare("211"))
{strcpy(p1[i].District_camp,"Ha Giang");}
if( !z.compare("212"))
{strcpy(p1[i].District_camp,"Tuyen Quang");}
if( !z.compare("220"))
{strcpy(p1[i].District_camp,"Cao Bang");}
if( !z.compare("230"))
{strcpy(p1[i].District_camp,"Lang Son");}
if( !z.compare("240"))
{strcpy(p1[i].District_camp,"Hoang Lien Son");}
if( !z.compare("241"))
{strcpy(p1[i].District_camp,"Lao Cai");}
if( !z.compare("242"))
{strcpy(p1[i].District_camp,"Yen Bai");}
if( !z.compare("250"))
{strcpy(p1[i].District_camp,"Bac Thai");}
if( !z.compare("251"))
{strcpy(p1[i].District_camp,"Bac Kan");}
if( !z.compare("252"))
{strcpy(p1[i].District_camp,"Thai Nguyen");}
if( !z.compare("260"))
{strcpy(p1[i].District_camp,"Vinh Phu");}
if( !z.compare("261"))
{strcpy(p1[i].District_camp,"Phu Tho");}
if( !z.compare("262"))
{strcpy(p1[i].District_camp,"Vinh Phuc");}
if( !z.compare("270"))
{strcpy(p1[i].District_camp,"Ha Bac");}
if( !z.compare("271"))
{strcpy(p1[i].District_camp,"Bac Giang");}
if( !z.compare("272"))
{strcpy(p1[i].District_camp,"Bac Ninh");}
if( !z.compare("280"))
{strcpy(p1[i].District_camp,"Quang Ninh");}
if( !z.compare("300"))
{strcpy(p1[i].District_camp,"Northwest");}
if( !z.compare("310"))
{strcpy(p1[i].District_camp,"Lai Chau");}
if( !z.compare("320"))
{strcpy(p1[i].District_camp,"Son La");}
if( !z.compare("321"))
{strcpy(p1[i].District_camp,"Son La");}
if( !z.compare("322"))
{strcpy(p1[i].District_camp,"Hoa Binh");}
if( !z.compare("400"))
{strcpy(p1[i].District_camp,"North Central");}
if( !z.compare("410"))
{strcpy(p1[i].District_camp,"Thanh Hoa");}
if( !z.compare("420"))
{strcpy(p1[i].District_camp,"Nghe Tinh");}
if( !z.compare("421"))
{strcpy(p1[i].District_camp,"Nghe An");}
if( !z.compare("422"))
{strcpy(p1[i].District_camp,"Ha Tinh");}
if( !z.compare("430"))
{strcpy(p1[i].District_camp,"Quang Binh");}
if( !z.compare("440"))
{strcpy(p1[i].District_camp,"Quang Tri");}
if( !z.compare("450"))
{strcpy(p1[i].District_camp,"Thua Thien - Hue");}
if( !z.compare("500"))
{strcpy(p1[i].District_camp,"Central Coast");}
if( !z.compare("510"))
{strcpy(p1[i].District_camp,"Quang Nam - Da Nang");}
if( !z.compare("511"))
{strcpy(p1[i].District_camp,"Da Nang city");}
if( !z.compare("512"))
{strcpy(p1[i].District_camp,"Quang Nam");}
if( !z.compare("520"))
{strcpy(p1[i].District_camp,"Binh Dinh");}
if( !z.compare("530"))
{strcpy(p1[i].District_camp,"Quang Ngai");}
if( !z.compare("540"))
{strcpy(p1[i].District_camp,"Phu Yen");}
if( !z.compare("550"))
{strcpy(p1[i].District_camp,"Khanh Hoa");}
if( !z.compare("600"))
{strcpy(p1[i].District_camp,"Central Highlands");}
if( !z.compare("610"))
{strcpy(p1[i].District_camp,"Gia Lai - Kon Tum");}
if( !z.compare("611"))
{strcpy(p1[i].District_camp,"Kon Tum");}
if( !z.compare("612"))
{strcpy(p1[i].District_camp,"Gia Lai");}
if( !z.compare("620"))
{strcpy(p1[i].District_camp,"Dac Lac");}
if( !z.compare("700"))
{strcpy(p1[i].District_camp,"Southeast");}
if( !z.compare("710"))
{strcpy(p1[i].District_camp,"Thuan Hai");}
if( !z.compare("711"))
{strcpy(p1[i].District_camp,"Ninh Thuan");}
if( !z.compare("712"))
{strcpy(p1[i].District_camp,"Binh Thuan");}
if( !z.compare("720"))
{strcpy(p1[i].District_camp,"Lam Dong");}
if( !z.compare("730"))
{strcpy(p1[i].District_camp,"Ho Chi Minh City");}
if( !z.compare("740"))
{strcpy(p1[i].District_camp,"Song Be");}
if( !z.compare("741"))
{strcpy(p1[i].District_camp,"Binh Duong");}
if( !z.compare("742"))
{strcpy(p1[i].District_camp,"Binh Phuoc");}
if( !z.compare("750"))
{strcpy(p1[i].District_camp,"Tay Ninh");}
if( !z.compare("760"))
{strcpy(p1[i].District_camp,"Dong Nai");}
if( !z.compare("770"))
{strcpy(p1[i].District_camp,"Vung Tau - Con Dao");}
if( !z.compare("800"))
{strcpy(p1[i].District_camp,"Mekong River Delta");}
if( !z.compare("810"))
{strcpy(p1[i].District_camp,"Long An");}
if( !z.compare("820"))
{strcpy(p1[i].District_camp,"Dong Thap");}
if( !z.compare("830"))
{strcpy(p1[i].District_camp,"An Giang");}
if( !z.compare("840"))
{strcpy(p1[i].District_camp,"Tien Giang");}
if( !z.compare("850"))
{strcpy(p1[i].District_camp,"Ben Tre");}
if( !z.compare("860"))
{strcpy(p1[i].District_camp,"Cuu Long");}
if( !z.compare("861"))
{strcpy(p1[i].District_camp,"Vinh Long");}
if( !z.compare("862"))
{strcpy(p1[i].District_camp,"Tra Vinh");}
if( !z.compare("870"))
{strcpy(p1[i].District_camp,"Hau Giang");}
if( !z.compare("871"))
{strcpy(p1[i].District_camp,"Can Tho");}
if( !z.compare("872"))
{strcpy(p1[i].District_camp,"Soc Trang");}
if( !z.compare("880"))
{strcpy(p1[i].District_camp,"Kien Giang");}
if( !z.compare("890"))
{strcpy(p1[i].District_camp,"Minh Hai");}
if( !z.compare("891"))
{strcpy(p1[i].District_camp,"Bac Lieu");}
if( !z.compare("892"))
{strcpy(p1[i].District_camp,"Ca Mau");}
if( !z.compare("997"))
{strcpy(p1[i].District_camp,"Moved within province");}
if( !z.compare("998"))
{strcpy(p1[i].District_camp,"Abroad");}
if( !z.compare("999"))
{strcpy(p1[i].District_camp,"Unknown");yrsinlocniuflag=1;}









if(!yrsinlocniuflag){
mfl<<p1[i].District_cam<<";"<<p1[i].District_camp<<"\n";}
yrsinlocniuflag=0;


}
}ct_camp,"Minh Hai");}
if( !z.compare("891"))
{strcpy(p1[i].District_camp,"Bac Lieu");}
if( !z.compare("892"))
{strcpy(p1[i].District_camp,"Ca Mau");}
if( !z.compare("997