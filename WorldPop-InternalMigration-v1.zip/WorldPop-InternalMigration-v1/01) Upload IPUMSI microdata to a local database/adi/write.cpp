
#include "targetver.h"
#include "stdafx.h"
using namespace std;


int main(int argc, char* argv[])
{
string str,x,y,z,w,v,u,s;
	ifstream in;
	in.open("g:\\camduist2.txt");
	if(!in)
	{
		cout<<"Couldn't open file";
		exit(1);
	}
	ofstream mfl;
  mfl.open ("g:\\viet12.txt");
  if(!mfl)
	{
		cout<<"Couldn't open file";
		exit(1);
	}

	int i=0,m=0,flag=0;
	
	
	
	while(!in.eof())
	{
		//in.getline(temp, 100);
		//str.assign( temp, temp+101 );
		getline ( in, str, '\n' );
	string::size_type loc2 = str.find( ";", 0 );
	string::size_type loc1 = str.find( "/0", 0 );
	x=str.substr(0,loc2);
	y=str.substr(loc2+1,loc1);

		mfl<<"if( !y.compare("<<x<<") )"<<"\n";
		mfl<<"strcpy(p1[i].District_camp,"<<y<<");}"<<"\n";


}




}l;
  mfl.open ("g:\\viet12.txt");
  if(!mfl)
	{
		cout<<"Couldn't open file";
		exit(1);
	}

	int i=0,m=0,flag=0;
	
	
	
	while(!in.eof())
	{
		//in.getline(temp, 100);
		//str.assign( temp, temp+101 );
		getline ( in, str, '\n' );
	string