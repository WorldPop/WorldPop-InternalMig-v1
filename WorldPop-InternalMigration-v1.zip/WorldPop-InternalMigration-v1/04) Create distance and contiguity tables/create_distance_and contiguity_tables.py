# This script depends on two ArcGIS toolboxes ("Additional Conversion Tools" and "Calculate Geodesic Distance") that are distributed with it

# The input to this script must be a polygon shapfile, representing subnational admin units,
# the first three caracthers of the input shapefile name must be the ISO three letter code for the country the shapefile refers to (https://en.wikipedia.org/wiki/ISO_3166-1)
# The attribute table of the input shapefile must contain the following three fields: "IPUMSID", "TotPop","UrbanProp", and "AREA_KM"

# The "Calculate Total Pop and Urban Proportion" tool in the "Migration" ArcGIS toolbox (i.e., script #3 in the WorldPop-InternalMigration code)
# can be used to calculate "TotPop" and "UrbanProp" for each polygon in the input shapefile

# the script also requires that the following three folders are in the working directory (i.e., in the "country_dir" specified below):
# "Gravity", "Scratch", and "Spatial_units"; wih the latter containing the input polygon shapfile


import arcpy
import os
import sys
import datetime
arcpy.CheckOutExtension("spatial")
# set the paths of the two ArcGIS toolboxes needed to
arcpy.ImportToolbox("C:/local/GIS_projects/Toolbox/AdditionalConversion/Additional Conversion Tools")
arcpy.ImportToolbox("C:/local/GIS_projects/Toolbox/Calculate Geodesic Distance")

# set the following variables

# must be set to either "AFRICA", "ASIA", or "LAC"
CONTINENT = "AFRICA"

# ISO 3-digit country code (Namibia is used as an example below)
ISO = "NAM"
# country name
country = "Namibia"
# set the working directory
country_dir = "C:/local/Namibia/"
scratch_dir = country_dir + "Scratch/"
# set the input shapefile name (with extension)
shapefile = country_dir + "Spatial_units/" + ISO + "_AdminUnits.shp"
# field used to uniquely identify each polygon in the input polygon shapfile
shapefile_field = "IPUMSID"

# environment
arcpy.env.overwriteOutput = True
arcpy.env.workspace = scratch_dir
arcpy.env.scratchWorkspace = scratch_dir

# make sure everything exists
if(not os.path.exists(country_dir)) :
    print("Country directory does not exist.")
    sys.exit(1)
if(not os.path.exists(scratch_dir)) :
    os.mkdir(scratch_dir)

# add an "CONTINENT" field if it does not exist
to_add0 = "CONTINENT"
# create a list of existing field names
fieldList0 = arcpy.ListFields(shapefile)
fieldName0 = [f.name for f in fieldList0]
# for to_add in in the fieldName:
if to_add0 in fieldName0:
    print "Already exists!"
else:
    arcpy.AddField_management(shapefile, to_add0, "TEXT")
    arcpy.CalculateField_management(shapefile, "CONTINENT", '"""'+CONTINENT+'"""', "PYTHON_9.3")

# add an "ISO" field if it does not exist
to_add = "ISO"
# create a list of existing field names
fieldList = arcpy.ListFields(shapefile)
fieldName = [f.name for f in fieldList]
# for to_add in in the fieldName:
if to_add in fieldName:
    print "Already exists!"
else:
    arcpy.AddField_management(shapefile, to_add, "TEXT")
    arcpy.CalculateField_management(shapefile, "ISO", '"""'+ISO+'"""', "PYTHON_9.3")


# create centroids
# FeatureToPoint_management (in_features, out_feature_class, {point_location})
centroids = arcpy.FeatureToPoint_management(shapefile, "centroids", "CENTROID")
# Add x,y coordinates that will be appended as POINT_X and POINT_Y fields
# AddXY_management (in_features)
centroids = arcpy.AddXY_management(centroids)
# JoinField_management (in_data, in_field, join_table, join_field, {fields})
# {fields} represents the fields from the join table to be included in the join as [fields,...]
arcpy.JoinField_management(centroids, "ORIG_FID", shapefile, "FID", ["TotPop", "UrbanProp","AREA_KM"])


# calculate Geodesic distances between centroids using the "Calculate Geodesic Distance" Toolbox (i.e., the "CalcGeodesicDist" Tool)
distance = arcpy.CalcGeodesicDist(centroids, centroids, scratch_dir + "geo_dist", scratch_dir + "geo_dist_XYToLine.shp")


# USE "IN_FID" in the "distance" table to join "centroids" to "distance"
arcpy.JoinField_management(distance, "IN_FID", centroids, "FID", ["IPUMSID", "POINT_X", "POINT_Y", "TotPop", "UrbanProp", "AREA_KM", "ISO", "CONTINENT"])
arcpy.AddField_management(distance, "IN_IPUMS", "LONG")
arcpy.CalculateField_management(distance, "IN_IPUMS", "[IPUMSID]")
arcpy.DeleteField_management(distance, "IPUMSID")
# Add new field
arcpy.AddField_management(distance, "NODEI", "LONG")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "NODEI", "!IN_IPUMS!", "PYTHON_9.3")
# Delete the old field (if necessary)
arcpy.DeleteField_management(distance, "IN_IPUMS")
# Add new field
arcpy.AddField_management(distance, "LONFR", "DOUBLE")
# Calculates the new field based on old field values
arcpy.CalculateField_management(distance, "LONFR", "!POINT_X!", "PYTHON_9.3")
# Delete the old field
arcpy.DeleteField_management(distance, "POINT_X")
# Add new field
arcpy.AddField_management(distance, "LATFR", "DOUBLE")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "LATFR", "!POINT_Y!", "PYTHON_9.3")
# Delete the old field
arcpy.DeleteField_management(distance, "POINT_Y")
# Add new field
arcpy.AddField_management(distance, "POPI", "DOUBLE")
#Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "POPI", "!TotPop!", "PYTHON_9.3")
# Delete the old field (if necessary)
arcpy.DeleteField_management(distance, "TotPop")
# Add new field
arcpy.AddField_management(distance, "URBANPROPI", "DOUBLE")
#Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "URBANPROPI", "!UrbanProp!", "PYTHON_9.3")
# Delete the old field (if necessary)
arcpy.DeleteField_management(distance, "UrbanProp")
# Add new field
arcpy.AddField_management(distance, "AREAI", "FLOAT")
#Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "AREAI", "!AREA_KM!", "PYTHON_9.3")
# Delete the old field (if necessary)
arcpy.DeleteField_management(distance, "AREA_KM")

# USE NEAR_FID in the "distance" table to join "centoids" to "distance"
arcpy.JoinField_management(distance, "NEAR_FID", centroids, "FID", ["IPUMSID", "POINT_X", "POINT_Y", "TotPop", "UrbanProp", "AREA_KM"])
arcpy.AddField_management(distance, "NEAR_IPUMS", "LONG")
arcpy.CalculateField_management(distance, "NEAR_IPUMS", "[IPUMSID]")
arcpy.DeleteField_management(distance, "IPUMSID")
# Add new field
arcpy.AddField_management(distance, "NODEJ", "LONG")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "NODEJ", "!NEAR_IPUMS!", "PYTHON_9.3")
# Delete the old field (if necessary)
arcpy.DeleteField_management(distance, "NEAR_IPUMS")
# Add new field
arcpy.AddField_management(distance, "LONTO", "DOUBLE")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "LONTO", "!POINT_X!", "PYTHON_9.3")
# Delete the old field
arcpy.DeleteField_management(distance, "POINT_X")
# Add new field
arcpy.AddField_management(distance, "LATTO", "DOUBLE")
#Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "LATTO", "!POINT_Y!", "PYTHON_9.3")
# Delete the old field
arcpy.DeleteField_management(distance, "POINT_Y")
# Add new field
arcpy.AddField_management(distance, "POPJ", "DOUBLE")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "POPJ", "!TotPop!", "PYTHON_9.3")
# Delete the old field
arcpy.DeleteField_management(distance, "TotPop")
# Add new field
arcpy.AddField_management(distance, "URBANPROPJ", "DOUBLE")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "URBANPROPJ", "!UrbanProp!", "PYTHON_9.3")
# Delete the old field
arcpy.DeleteField_management(distance, "UrbanProp")
# Add new field
arcpy.AddField_management(distance, "AREAJ", "FLOAT")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "AREAJ", "!AREA_KM!", "PYTHON_9.3")
# Delete the old field (if necessary)
arcpy.DeleteField_management(distance, "AREA_KM")
# Add new field
arcpy.AddField_management(distance, "DISTIJ", "DOUBLE")
# Calculate the new field based on old field values
arcpy.CalculateField_management(distance, "DISTIJ", "!GEO_DIST!", "PYTHON_9.3")
# Delete the old field calle "GEO_DIST" that is calculated by the "Calculate Geodesic Distance" Toolbox
arcpy.DeleteField_management(distance, "GEO_DIST")

# save "distance"
if(os.path.exists(country_dir + "Gravity/distance.csv")) :
    os.remove(country_dir + "Gravity/distance.csv")
arcpy.TableToExcel_conversion2(distance, country_dir + "Gravity/distance.csv", "CSV")


# calculate contiguity
arcpy.GenerateSpatialWeightsMatrix_stats(shapefile, "IPUMSID", "swm.swm", "CONTIGUITY_EDGES_ONLY", "", "", "" , "" , "NO_STANDARDIZATION")
contiguity = arcpy.ConvertSpatialWeightsMatrixtoTable_stats("swm.swm", "contiguity")

# save "contiguity"
if(os.path.exists(country_dir + "Gravity/contiguity.csv")) :
    os.remove(country_dir + "Gravity/contiguity.csv")
arcpy.TableToExcel_conversion2(str(contiguity) + ".dbf", country_dir + "Gravity/contiguity.csv", "CSV")